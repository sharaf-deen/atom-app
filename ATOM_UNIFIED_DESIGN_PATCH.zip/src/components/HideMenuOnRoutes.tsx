'use client'
import { usePathname } from 'next/navigation'
import * as React from 'react'
export default function HideMenuOnRoutes({ routes, children }: { routes: string[]; children: React.ReactNode }) {
  const pathname = usePathname()
  if (routes.includes(pathname)) return null
  return <>{children}</>
}
