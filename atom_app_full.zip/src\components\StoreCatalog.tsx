// src/components/StoreCatalog.tsx
'use client'

import { useEffect, useMemo, useState } from 'react'
import { formatCurrency, toPriceString, parsePriceToCents } from '@/lib/money'

type Category = 'kimono' | 'rashguard' | 'short' | 'belt'
type Product = {
  id: string
  category: Category
  name: string
  color: string | null
  size: string | null
  price_cents: number
  currency?: string | null
  inventory_qty?: number
  is_active: boolean
}

const CATEGORIES: Category[] = ['kimono', 'rashguard', 'short', 'belt']
const PER_PAGE = 4

export default function StoreCatalog({
  showAdd = true,
  canManage = false,
}: {
  showAdd?: boolean
  canManage?: boolean
}) {
  const [items, setItems] = useState<Product[]>([])
  const [err, setErr] = useState<string>('')
  const [info, setInfo] = useState<string>('')
  const [busy, setBusy] = useState(false)

  // Edition
  const [editingId, setEditingId] = useState<string | null>(null)
  const [edit, setEdit] = useState<Partial<Product>>({})
  const [editPrice, setEditPrice] = useState<string>('')

  // Filtres
  const [cat, setCat] = useState<'all' | Category>('all')
  const [active, setActive] = useState<'all' | '1' | '0'>('all')

  // Pagination
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const totalPages = useMemo(() => Math.max(1, Math.ceil(total / PER_PAGE)), [total])

  async function load(p = page) {
    setErr('')
    try {
      const params = new URLSearchParams()
      params.set('page', String(p))
      params.set('limit', String(PER_PAGE))
      if (canManage) params.set('all', '1')
      if (cat !== 'all') params.set('category', cat)
      if (canManage && active !== 'all') params.set('active', active)

      const r = await fetch(`/api/store/products/list?${params.toString()}`, { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setErr(j?.error || j?.details || 'Failed to load products')
        setItems([])
        setTotal(0)
        return
      }

      const itemsRaw: Product[] = Array.isArray(j.items) ? j.items : []
      const totalFromApi =
        Number.isFinite(Number(j?.total)) ? Number(j.total) : null

      if (totalFromApi !== null) {
        // ✅ L’API pagine déjà (elle fournit total) → ne pas re-slicer côté client
        setItems(itemsRaw)
        setTotal(totalFromApi)
        setPage(Number(j.page || p))
      } else {
        // 🔁 Fallback local si l’API renvoie toute la liste
        const computedTotal = itemsRaw.length
        const start = (p - 1) * PER_PAGE
        const pageItems = itemsRaw.slice(start, start + PER_PAGE)
        setItems(pageItems)
        setTotal(computedTotal)
        setPage(p)
      }
    } catch (e: any) {
      setErr(String(e?.message || e))
      setItems([])
      setTotal(0)
    }
  }

  // Recharge au changement de filtres (et au mount)
  useEffect(() => {
    setPage(1)
    load(1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canManage, cat, active])

  function addToCart(p: Product) {
    const ev = new CustomEvent('cart:add', { detail: { product_id: p.id, qty: 1, product: p } })
    window.dispatchEvent(ev)
  }

  // ---- Edit helpers ----
  function startEdit(p: Product) {
    setEditingId(p.id)
    setEdit({
      id: p.id,
      category: p.category,
      name: p.name,
      color: p.color ?? '',
      size: p.size ?? '',
      price_cents: p.price_cents,
      inventory_qty: p.inventory_qty ?? 0,
      is_active: p.is_active,
      currency: p.currency ?? 'EGP',
    } as Partial<Product>)
    setEditPrice(toPriceString(p.price_cents)) // ex: "450.00"
    setInfo('')
    setErr('')
  }
  function cancelEdit() {
    setEditingId(null)
    setEdit({})
    setEditPrice('')
  }
  function update<K extends keyof Product>(k: K, v: any) {
    setEdit((e) => ({ ...e, [k]: v }))
  }

  async function saveEdit() {
    if (!editingId) return
    setBusy(true)
    setErr('')
    setInfo('')
    try {
      const payload: any = {
        id: editingId,
        category: edit.category,
        name: (edit.name || '').toString(),
        color: typeof edit.color === 'string' ? edit.color : null,
        size: typeof edit.size === 'string' ? edit.size : null,
        price_cents: parsePriceToCents(editPrice),
        inventory_qty: Number(edit.inventory_qty ?? 0),
        is_active: !!edit.is_active,
      }
      const r = await fetch('/api/store/products/update', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setErr(j?.details || j?.error || 'Update failed')
        return
      }
      setInfo('Product updated.')
      setEditingId(null)
      setEditPrice('')
      await load(page) // rester sur la page courante
    } catch (e: any) {
      setErr(String(e?.message || e))
    } finally {
      setBusy(false)
    }
  }

  async function deleteItem(id: string) {
    if (!confirm('Delete this product? This cannot be undone.')) return
    setBusy(true)
    setErr('')
    setInfo('')
    try {
      const r = await fetch(`/api/store/products/delete?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setErr(j?.hint || j?.details || j?.error || 'Delete failed')
        return
      }
      setInfo('Product deleted.')
      // recharge et si la page courante devient vide, recule d'une page
      await load(page)
      if (items.length === 1 && page > 1) {
        await load(page - 1)
      }
    } catch (e: any) {
      setErr(String(e?.message || e))
    } finally {
      setBusy(false)
    }
  }

  async function toggleActive(id: string, nextActive: boolean) {
    setBusy(true)
    setErr('')
    setInfo('')
    try {
      const r = await fetch('/api/store/products/update', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, is_active: nextActive }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setErr(j?.details || j?.error || 'Toggle failed')
        return
      }
      setInfo(nextActive ? 'Product activated.' : 'Product deactivated.')
      await load(page)
    } catch (e: any) {
      setErr(String(e?.message || e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <section className="rounded-xl border bg-white p-4">
      <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
        <h2 className="font-semibold">Catalog</h2>

        {/* Filtres */}
        <div className="flex flex-wrap items-center gap-2 sm:ml-4">
          <select
            value={cat}
            onChange={(e) => setCat(e.target.value as any)}
            className="px-2 py-1.5 border rounded"
            aria-label="Category"
          >
            <option value="all">All categories</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c.replace('_', ' ')}
              </option>
            ))}
          </select>

          {canManage && (
            <select
              value={active}
              onChange={(e) => setActive(e.target.value as any)}
              className="px-2 py-1.5 border rounded"
              aria-label="Active filter"
            >
              <option value="all">All (active + inactive)</option>
              <option value="1">Only active</option>
              <option value="0">Only inactive</option>
            </select>
          )}
        </div>

        <button onClick={() => load(page)} className="sm:ml-auto text-sm px-2 py-1 rounded border hover:bg-gray-50">
          Refresh
        </button>
      </div>

      {(err || info) && (
        <div className="mt-3 text-sm">
          {err && <div className="text-red-600">{err}</div>}
          {info && <div className="text-green-700">{info}</div>}
        </div>
      )}

      {/* Compteur pagination (top) */}
      <div className="mt-3 text-xs text-gray-600">
        Page <strong>{page}</strong> / {totalPages} · Total {total} · {PER_PAGE}/page
      </div>

      {/* Grid produits */}
      <div className="mt-3 grid gap-3 grid-cols-1 sm:grid-cols-3 lg:grid-cols-4">
        {items.map((p) => {
          const isEditing = editingId === p.id
          const currency = p.currency ?? 'EGP'
          return (
            <div key={p.id} className="border rounded-lg p-3 bg-gray-50">
              {!isEditing ? (
                <>
                  <div className="text-xs text-gray-500 uppercase flex items-center gap-2">
                    {p.category.replace('_', ' ')}
                    {!p.is_active && (
                      <span className="text-[10px] px-1 py-0.5 rounded border bg-white">inactive</span>
                    )}
                  </div>
                  <div className="font-medium">{p.name}</div>
                  <div className="text-sm text-gray-600">
                    {p.color || p.size ? [p.color, p.size].filter(Boolean).join(' · ') : '—'}
                  </div>
                  <div className="mt-2 text-lg font-semibold">
                    {formatCurrency(p.price_cents, 'en-EG', currency)}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">Stock: {p.inventory_qty ?? 0}</div>

                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {showAdd && (
                      <button
                        onClick={() => addToCart(p)}
                        className="px-3 py-1.5 rounded border bg-white hover:bg-gray-100"
                      >
                        Add to cart
                      </button>
                    )}
                    {canManage && (
                      <>
                        <button
                          onClick={() => startEdit(p)}
                          className="px-3 py-1.5 rounded border hover:bg-white"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => toggleActive(p.id, !p.is_active)}
                          className="px-3 py-1.5 rounded border hover:bg-white"
                        >
                          {p.is_active ? 'Deactivate' : 'Activate'}
                        </button>
                        <button
                          onClick={() => deleteItem(p.id)}
                          className="px-3 py-1.5 rounded border hover:bg-white text-red-600"
                        >
                          Delete
                        </button>
                      </>
                    )}
                  </div>
                </>
              ) : (
                // ---- Editing form ----
                <div className="space-y-2">
                  <div className="text-sm font-medium">Edit product</div>

                  <label className="grid gap-1">
                    <span className="text-xs">Category</span>
                    <select
                      value={edit.category || 'kimono'}
                      onChange={(e) => update('category', e.target.value as Category)}
                      className="px-2 py-1 border rounded"
                    >
                      {CATEGORIES.map((c) => (
                        <option key={c} value={c}>
                          {c.replace('_', ' ')}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="grid gap-1">
                    <span className="text-xs">Name</span>
                    <input
                      value={edit.name || ''}
                      onChange={(e) => update('name', e.target.value)}
                      className="px-2 py-1 border rounded"
                    />
                  </label>

                  <div className="grid grid-cols-2 gap-2">
                    <label className="grid gap-1">
                      <span className="text-xs">Color</span>
                      <input
                        value={typeof edit.color === 'string' ? edit.color : ''}
                        onChange={(e) => update('color', e.target.value)}
                        className="px-2 py-1 border rounded"
                      />
                    </label>
                    <label className="grid gap-1">
                      <span className="text-xs">Size</span>
                      <input
                        value={typeof edit.size === 'string' ? edit.size : ''}
                        onChange={(e) => update('size', e.target.value)}
                        className="px-2 py-1 border rounded"
                      />
                    </label>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <label className="grid gap-1">
                      <span className="text-xs">Price (EGP)</span>
                      <input
                        type="number"
                        inputMode="decimal"
                        step="0.01"
                        min="0"
                        value={editPrice}
                        onChange={(e) => setEditPrice(e.target.value)}
                        className="px-2 py-1 border rounded"
                        placeholder="0.00"
                      />
                    </label>
                    <label className="grid gap-1">
                      <span className="text-xs">Inventory qty</span>
                      <input
                        type="number"
                        value={Number(edit.inventory_qty ?? 0)}
                        onChange={(e) => update('inventory_qty', Number(e.target.value || 0))}
                        className="px-2 py-1 border rounded"
                        min={0}
                      />
                    </label>
                  </div>

                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={!!edit.is_active}
                      onChange={(e) => update('is_active', e.target.checked)}
                    />
                    <span className="text-xs">Active</span>
                  </label>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={saveEdit}
                      disabled={busy}
                      className="px-3 py-1.5 rounded border bg-black text-white disabled:opacity-60"
                    >
                      {busy ? 'Saving…' : 'Save'}
                    </button>
                    <button
                      onClick={cancelEdit}
                      disabled={busy}
                      className="px-3 py-1.5 rounded border hover:bg-white"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          )
        })}
        {items.length === 0 && (
          <div className="text-sm text-gray-500">No products found with current filters.</div>
        )}
      </div>

      {/* Pagination */}
      <div className="mt-4 flex items-center justify-center gap-2">
        <button
          onClick={() => load(Math.max(1, page - 1))}
          disabled={page <= 1}
          className="px-2 py-1 rounded border bg-white hover:bg-gray-50 disabled:opacity-50"
        >
          Prev
        </button>
        <div className="text-xs text-gray-600">
          Page <strong>{page}</strong> / {totalPages} · Total {total} · {PER_PAGE}/page
        </div>
        <button
          onClick={() => load(Math.min(totalPages, page + 1))}
          disabled={page >= totalPages}
          className="px-2 py-1 rounded border bg-white hover:bg-gray-50 disabled:opacity-50"
        >
          Next
        </button>
      </div>
    </section>
  )
}
