// app/profile/page.tsx
import { redirect } from 'next/navigation'
import { getSessionUser } from '@/lib/session'
import QrCard from '@/components/QrCard'
import ProfileSubscriptions from '@/components/ProfileSubscriptions'


export default async function ProfilePage() {
  const user = await getSessionUser()
  if (!user) redirect('/login')

  // ✅ QR visible pour member, assistant_coach, coach
  const canShowQR = ['member', 'assistant_coach', 'coach'].includes(user.role)
  const canShowSubscriptions = ['member'].includes(user.role)

  return (
    <main className="p-6 max-w-2xl mx-auto space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">My Profile</h1>
        <span className="text-sm px-2 py-1 rounded bg-gray-100">
          <div>Role: <strong>{user.role}</strong></div>
          <div>ID : <strong>{user.member_id}</strong></div>
        </span>
      </header>

      <section className="rounded-xl border p-4 grid gap-2">
        <div className="text-sm text-gray-600">Full Name</div>
        <div className="text-lg">{user.full_name ?? '—'}</div>
        <div className="text-sm text-gray-600 mt-4">Email</div>
        <div className="text-base">{user.email ?? '—'}</div>
        <div className="text-sm text-gray-600 mt-4">Phone</div>
        <div className="text-base">{user.phone ?? '—'}</div>
      </section>

      {canShowQR && !!user.qr_code && (
        <QrCard value={user.qr_code} title="My Access QR" size={220} />
      )}
      {canShowSubscriptions && <ProfileSubscriptions />}
    </main>
  )
}
