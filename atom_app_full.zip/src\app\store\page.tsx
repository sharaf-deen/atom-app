// src/app/store/page.tsx
export const dynamic = 'force-dynamic'
export const revalidate = 0

import { getSessionUser } from '@/lib/session'
import StoreCatalog from '@/components/StoreCatalog'
import StoreCart from '@/components/StoreCart'
import StoreOrdersList from '@/components/StoreOrdersList'
import StoreProductForm from '@/components/StoreProductForm'

const BUYER_ROLES = new Set(['member', 'assistant_coach', 'coach'])

export default async function StorePage() {
  const me = await getSessionUser()
  if (!me) {
    return (
      <main className="p-6">
        <h1 className="text-xl font-semibold">Store</h1>
        <p className="text-sm text-gray-600 mt-2">Please sign in.</p>
      </main>
    )
  }

  const role = me.role
  const isSuperAdmin = role === 'super_admin'
  const isAdmin = role === 'admin'
  const isBuyer = BUYER_ROLES.has(role)

  // Règles :
  // - member/assistant_coach/coach : Cart + "My orders"
  // - reception : catalogue uniquement
  // - admin : catalogue uniquement (pas de gestion, pas de commandes)
  // - super_admin : gestion du catalogue + "All orders" (pas de Cart)

  const showCart = isBuyer
  const canManageCatalog = isSuperAdmin
  const showMyOrders = isBuyer
  const showAllOrders = isSuperAdmin

  return (
    <main className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <h1 className="text-xl font-semibold">Store</h1>
      </div>

      {/* Super admin : ajout/édition produits */}
      {canManageCatalog && (
        <section className="rounded-xl border bg-white p-4">
          <h2 className="font-semibold mb-3">Catalog management</h2>
          {/* ⚠️ Ne pas passer de callback ici (Server → Client) */}
          <StoreProductForm />
        </section>
      )}

      {/* Catalogue (Add to cart visible seulement pour les rôles acheteurs) */}
      <StoreCatalog showAdd={showCart} canManage={canManageCatalog} />

      {/* Panier (uniquement member/assistant_coach/coach) */}
      {showCart && (
        <section className="rounded-xl border bg-white p-4">
          <h2 className="font-semibold mb-3">Cart</h2>
          <StoreCart />
        </section>
      )}

      {/* Mes commandes (uniquement member/assistant_coach/coach) */}
      {showMyOrders && (
        <section className="rounded-xl border bg-white p-4">
          <h2 className="font-semibold mb-3">My orders</h2>
          <StoreOrdersList mode="mine" />
        </section>
      )}

      {/* Toutes les commandes (uniquement super_admin) */}
      {showAllOrders && (
        <section className="rounded-xl border bg-white p-4">
          <h2 className="font-semibold mb-3">Orders List</h2>
          <StoreOrdersList mode="admin" />
        </section>
      )}
    </main>
  )
}
