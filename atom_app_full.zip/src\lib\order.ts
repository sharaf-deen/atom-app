// src/lib/order.ts

export type OrderStatus = 'pending' | 'confirmed' | 'ready' | 'delivered' | 'canceled'
export const ORDER_STATUSES: OrderStatus[] = ['pending', 'confirmed', 'ready', 'delivered', 'canceled']

export function isOrderStatus(x: unknown): x is OrderStatus {
  return typeof x === 'string' && (ORDER_STATUSES as string[]).includes(x)
}

export type PaymentMethod = 'cash' | 'card' | 'bank_transfer' | 'instapay'
export const PAYMENT_METHODS: PaymentMethod[] = ['cash', 'card', 'bank_transfer', 'instapay']

export function isPaymentMethod(x: unknown): x is PaymentMethod {
  return typeof x === 'string' && (PAYMENT_METHODS as string[]).includes(x)
}
