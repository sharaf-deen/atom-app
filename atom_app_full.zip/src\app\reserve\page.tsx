'use client';
import { useState } from 'react';
import { supabase } from '@/src/lib/supabaseClient';
import { useSession } from '@/src/lib/useSession';

export default function ReserveEquipmentPage() {
  const session = useSession();
  const [itemName, setItemName] = useState('Kimono');
  const [advance, setAdvance] = useState('500');
  const [msg, setMsg] = useState('');

  const submit = async () => {
    if (!session) { setMsg('Please login first.'); return; }
    const { error } = await supabase.from('equipment_reservations').insert({
      user_id: session.user.id,
      item_name: itemName,
      advance_paid: Number(advance)
    });
    if (error) setMsg('Error: ' + error.message);
    else setMsg('Reservation created!');
  };

  return (
    <main className="space-y-4">
      <h1 className="text-xl font-bold">Reserve Equipment (advance)</h1>
      <div className="space-y-2">
        <label className="block">
          <span>Item name</span>
          <input className="border px-3 py-2 w-full" value={itemName} onChange={e => setItemName(e.target.value)} />
        </label>
        <label className="block">
          <span>Advance (EGP)</span>
          <input className="border px-3 py-2 w-full" value={advance} onChange={e => setAdvance(e.target.value)} />
        </label>
      </div>
      <button onClick={submit} className="px-4 py-2 border rounded">Confirm Reservation</button>
      {msg && <p>{msg}</p>}
    </main>
  );
}
