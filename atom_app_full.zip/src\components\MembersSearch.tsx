// src/components/MembersSearch.tsx
'use client'

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import SubscribeDialog, { type Plan } from '@/components/SubscribeDialog'

type Role = 'member' | 'assistant_coach' | 'coach' | 'reception' | 'admin' | 'super_admin'

type MemberRow = {
  user_id: string
  email: string | null
  first_name: string | null
  last_name: string | null
  phone: string | null
  role: Role | null
  created_at: string | null
}

function fmtDate(d?: string | null) {
  if (!d) return '—'
  const date = d.length <= 10 ? new Date(d + 'T00:00:00Z') : new Date(d)
  if (isNaN(date.getTime())) return d
  return date.toLocaleDateString('en-GB', { year: 'numeric', month: 'short', day: '2-digit' })
}

export default function MembersSearch({ isStaff = false }: { isStaff?: boolean }) {
  const [q, setQ] = useState('')
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState<string>('')
  const [rows, setRows] = useState<MemberRow[]>([])

  async function runSearch(signal?: AbortSignal) {
    setLoading(true)
    setErr('')
    try {
      const r = await fetch(`/api/members/search?q=${encodeURIComponent(q)}`, {
        headers: { 'Accept': 'application/json' },
        signal,
      })
      const j = await r.json()
      if (!r.ok || !j.ok) {
        setErr(j?.error || 'Search failed')
        setRows([])
        return
      }
      setRows(j.items as MemberRow[])
    } catch (e: any) {
      if (e?.name !== 'AbortError') setErr(String(e?.message || e))
      setRows([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const ctrl = new AbortController()
    runSearch(ctrl.signal)
    return () => ctrl.abort()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const hasData = rows.length > 0

  return (
    <section className="space-y-3">
      <div className="flex items-center gap-2">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search by name, email or member id…"
          className="px-3 py-2 border rounded w-full max-w-md"
        />
        <button
          className="px-3 py-2 rounded border hover:bg-gray-50"
          onClick={() => runSearch()}
          disabled={loading}
        >
          {loading ? 'Searching…' : 'Search'}
        </button>
      </div>

      {err && (
        <div className="rounded border border-red-300 bg-red-50 text-red-700 text-sm px-3 py-2">
          {err}
        </div>
      )}

      {!hasData && !loading && !err && (
        <div className="text-sm text-gray-600">No members found.</div>
      )}

      {hasData && (
        <div className="overflow-x-auto rounded-xl border bg-white">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-gray-600">
              <tr>
                <th className="text-left px-3 py-2">Name</th>
                <th className="text-left px-3 py-2">Email</th>
                <th className="text-left px-3 py-2">Phone</th>
                <th className="text-left px-3 py-2">Joined</th>
                <th className="text-left px-3 py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((m) => {
                const name = [m.first_name ?? '', m.last_name ?? ''].join(' ').trim() || '—'
                return (
                  <tr key={m.user_id} className="border-t">
                    <td className="px-3 py-2">
                      <div className="font-medium">{name}</div>
                    </td>
                    <td className="px-3 py-2">{m.email ?? '—'}</td>
                    <td className="px-3 py-2">{m.phone ?? '—'}</td>
                    <td className="px-3 py-2">{fmtDate(m.created_at)}</td>
                    <td className="px-3 py-2">
                      <div className="flex flex-wrap items-center gap-2">
                        {/* View profile (always available) */}
                        <Link
                          href={`/members/${m.user_id}`}
                          className="px-2 py-1 rounded border hover:bg-gray-50"
                        >
                          View
                        </Link>

                        {/* Staff-only: quick subscribe */}
                        {isStaff && (
                          <SubscribeDialog
                            member={{
                              user_id: m.user_id,
                              email: m.email,
                              first_name: m.first_name,
                              last_name: m.last_name,
                            }}
                            defaultPlan={'1m' as Plan}
                            defaultSessions={10}
                            buttonLabel="Subscribe"
                          />
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  )
}
