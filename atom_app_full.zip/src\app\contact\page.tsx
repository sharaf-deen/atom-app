// src/app/contact/page.tsx
export const dynamic = 'force-dynamic'
export const revalidate = 0

import { getSessionUser } from '@/lib/session'
import ContactForm from '@/components/ContactForm'

export default async function ContactPage() {
  const me = await getSessionUser()
  if (!me) {
    return (
      <main className="p-6">
        <h1 className="text-xl font-semibold">Contact</h1>
        <p className="text-sm text-gray-600 mt-2">Please sign in.</p>
      </main>
    )
  }

  if (me.role !== 'member') {
    return (
      <main className="p-6">
        <h1 className="text-xl font-semibold">Contact</h1>
        <p className="text-sm text-gray-600 mt-2">This page is for members only.</p>
      </main>
    )
  }

  return (
    <main className="p-6 max-w-3xl mx-auto space-y-4">
      <h1 className="text-xl font-semibold">Contact Atom</h1>
      <p className="text-sm text-gray-600">
        Your message will be sent to the admin team. They’ll reply to the email on your account.
      </p>
      <ContactForm />
    </main>
  )
}
