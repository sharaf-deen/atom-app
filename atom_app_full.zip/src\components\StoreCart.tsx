// src/components/StoreCart.tsx
'use client'

import { useEffect, useMemo, useState } from 'react'
import { formatCurrency } from '@/lib/money'

type CartLine = {
  product_id: string
  name: string
  unit_price_cents: number
  qty: number
  currency?: string | null
}

type CartAddEvent = CustomEvent<{
  product_id: string
  qty: number
  product?: {
    id: string
    name: string
    price_cents: number
    currency?: string | null
  }
}>

const PAYMENT_METHODS = [
  { v: 'cash', label: 'Cash' },
  { v: 'card', label: 'Visa / Card' },
  { v: 'bank_transfer', label: 'Bank transfer' },
  { v: 'instapay', label: 'Instapay' },
] as const

export default function StoreCart() {
  const [lines, setLines] = useState<CartLine[]>([])
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState<string>('') // info / succès / erreur
  const [payment, setPayment] = useState<'cash'|'card'|'bank_transfer'|'instapay'>('cash')
  const [note, setNote] = useState('')

  // Écoute l’évènement envoyé par StoreCatalog: window.dispatchEvent(new CustomEvent('cart:add', …))
  useEffect(() => {
    function onAdd(e: Event) {
      const ev = e as CartAddEvent
      const { product_id, qty, product } = ev.detail || {}
      if (!product_id || !qty) return

      setLines((prev) => {
        const i = prev.findIndex((l) => l.product_id === product_id)
        if (i >= 0) {
          const next = [...prev]
          next[i] = { ...next[i], qty: next[i].qty + qty }
          return next
        }
        // snapshot du prix et du nom à l’instant de l’ajout
        return [
          ...prev,
          {
            product_id,
            name: product?.name ?? 'Item',
            unit_price_cents: Number(product?.price_cents ?? 0),
            currency: product?.currency ?? 'EGP',
            qty,
          },
        ]
      })
    }

    window.addEventListener('cart:add', onAdd as EventListener)
    return () => window.removeEventListener('cart:add', onAdd as EventListener)
  }, [])

  function inc(id: string) {
    setLines((prev) =>
      prev.map((l) => (l.product_id === id ? { ...l, qty: l.qty + 1 } : l))
    )
  }
  function dec(id: string) {
    setLines((prev) =>
      prev
        .map((l) => (l.product_id === id ? { ...l, qty: Math.max(1, l.qty - 1) } : l))
        .filter((l) => l.qty > 0)
    )
  }
  function removeLine(id: string) {
    setLines((prev) => prev.filter((l) => l.product_id !== id))
  }
  function clear() {
    setLines([])
    setNote('')
  }

  const subtotal = useMemo(
    () => lines.reduce((s, l) => s + l.unit_price_cents * l.qty, 0),
    [lines]
  )

  async function checkout() {
    if (lines.length === 0) return
    setBusy(true)
    setMsg('')
    try {
      // L’API applique la remise suivant le rôle (coach 30%, assistant 20%)
      const payload = {
        items: lines.map((l) => ({ product_id: l.product_id, qty: l.qty })),
        preferred_payment: payment,
        note: note.trim() || undefined,
      }
      const r = await fetch('/api/store/orders/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setMsg(j?.details || j?.error || 'Order failed')
        return
      }
      // j.total_cents, j.discount_pct disponibles en retour
      const totalStr = formatCurrency(Number(j.total_cents ?? 0), 'en-EG', 'EGP')
      const disc = Number(j.discount_pct ?? 0)
      setMsg(
        `Order placed. ${disc ? `Discount ${disc}% applied. ` : ''}Total = ${totalStr}.`
      )
      clear()
    } catch (e: any) {
      setMsg(String(e?.message || e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <section className="rounded-xl border bg-white p-4">
      <div className="flex items-center gap-2">
        <h2 className="font-semibold">Cart</h2>
        <div className="ml-auto text-sm text-gray-500">
          {/* Remise affichée à titre indicatif */}
          Discount is applied at checkout (coach 30%, assistant 20%).
        </div>
      </div>

      {lines.length === 0 ? (
        <p className="text-sm text-gray-500 mt-2">Your cart is empty.</p>
      ) : (
        <div className="mt-3 space-y-3">
          {lines.map((l) => {
            const lineTotal = l.unit_price_cents * l.qty
            return (
              <div key={l.product_id} className="flex items-start gap-3 border rounded p-2 bg-gray-50">
                <div className="flex-1">
                  <div className="font-medium">{l.name}</div>
                  <div className="text-xs text-gray-600">
                    Unit: {formatCurrency(l.unit_price_cents, 'en-EG', l.currency || 'EGP')}
                  </div>
                  <div className="mt-1 flex items-center gap-2">
                    <button
                      onClick={() => dec(l.product_id)}
                      className="px-2 py-1 border rounded"
                      aria-label="Decrease quantity"
                    >
                      −
                    </button>
                    <span className="w-8 text-center">{l.qty}</span>
                    <button
                      onClick={() => inc(l.product_id)}
                      className="px-2 py-1 border rounded"
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                    <button
                      onClick={() => removeLine(l.product_id)}
                      className="ml-3 px-2 py-1 border rounded text-red-600"
                    >
                      Remove
                    </button>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm">Line total</div>
                  <div className="font-semibold">
                    {formatCurrency(lineTotal, 'en-EG', l.currency || 'EGP')}
                  </div>
                </div>
              </div>
            )
          })}

          <div className="flex items-center justify-between border-t pt-3">
            <div className="text-sm text-gray-600">Subtotal</div>
            <div className="text-lg font-semibold">
              {formatCurrency(subtotal, 'en-EG', 'EGP')}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <label className="grid gap-1">
              <span className="text-sm">Preferred payment</span>
              <select
                value={payment}
                onChange={(e) => setPayment(e.target.value as any)}
                className="px-3 py-2 border rounded"
              >
                {PAYMENT_METHODS.map((m) => (
                  <option key={m.v} value={m.v}>{m.label}</option>
                ))}
              </select>
            </label>

            <label className="grid gap-1">
              <span className="text-sm">Note (optional)</span>
              <input
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="px-3 py-2 border rounded"
                placeholder="E.g. size exchange, pickup time…"
              />
            </label>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={checkout}
              disabled={busy || lines.length === 0}
              className={`px-3 py-2 rounded border ${busy ? 'bg-gray-200 text-gray-500' : 'bg-black text-white hover:opacity-90'}`}
            >
              {busy ? 'Placing…' : 'Place order'}
            </button>
            <button
              onClick={clear}
              disabled={busy || lines.length === 0}
              className="px-3 py-2 rounded border hover:bg-gray-50"
            >
              Clear
            </button>
            {msg && <span className="text-xs text-gray-600">{msg}</span>}
          </div>

          <p className="text-xs text-gray-500">
            After placing your order, please pay in cash or card at the gym, or via bank transfer / Instapay.
          </p>
        </div>
      )}
    </section>
  )
}
