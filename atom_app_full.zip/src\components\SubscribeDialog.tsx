// src/components/SubscribeDialog.tsx
'use client'

import { useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'

export type Plan = '1m' | '3m' | '6m' | '12m' | 'sessions'

function todayLocalDateStr() {
  const d = new Date()
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}` // YYYY-MM-DD (local)
}
function humanPlan(p: Plan) {
  switch (p) {
    case '1m': return '1 month'
    case '3m': return '3 months'
    case '6m': return '6 months'
    case '12m': return '12 months'
    case 'sessions': return 'Per sessions'
  }
}

export default function SubscribeDialog({
  member,
  defaultPlan,
  defaultStartDate,
  defaultSessions,
  buttonLabel = 'Subscribe',
  onCreated,
}: {
  member: { user_id: string; email: string | null; first_name: string | null; last_name: string | null }
  defaultPlan?: Plan
  defaultStartDate?: string // YYYY-MM-DD
  defaultSessions?: number  // 1..10
  buttonLabel?: string
  onCreated?: (payload: any) => void
}) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [plan, setPlan] = useState<Plan>(defaultPlan ?? '1m')
  const [sessions, setSessions] = useState<number>(Math.min(Math.max(defaultSessions ?? 10, 1), 10))
  const [amount, setAmount] = useState<string>('0')
  const [startDate, setStartDate] = useState<string>(defaultStartDate ?? todayLocalDateStr())
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string>('')
  const [successMsg, setSuccessMsg] = useState<string>('')

  useEffect(() => {
    if (open) {
      setPlan(defaultPlan ?? '1m')
      setSessions(Math.min(Math.max(defaultSessions ?? 10, 1), 10))
      setStartDate(defaultStartDate ?? todayLocalDateStr())
      setAmount('0')
      setErr('')
      setSuccessMsg('')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const fullName = useMemo(() => {
    const n = [member.first_name ?? '', member.last_name ?? ''].join(' ').trim()
    return n || member.email || member.user_id
  }, [member])

  const isTimePlan = plan !== 'sessions'
  const canSubmit =
    !busy &&
    amount !== '' &&
    Number(amount) >= 0 &&
    (isTimePlan ? /^\d{4}-\d{2}-\d{2}$/.test(startDate) : true)

  useEffect(() => {
    if (isTimePlan && !startDate) setStartDate(todayLocalDateStr())
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plan])

  async function submit() {
    if (!canSubmit) return
    setBusy(true)
    setErr('')
    setSuccessMsg('')
    try {
      const body: any = {
        memberId: member.user_id,
        plan,
        amount: Number(amount || 0),
      }
      if (isTimePlan) {
        body.start_date = startDate
      } else {
        body.sessions_total = sessions
      }

      const r = await fetch('/api/subscriptions/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })
      const j = await r.json()

      if (!r.ok || !j.ok) {
        setErr(j?.details || j?.error || 'Failed to create subscription')
        return
      }

      const msg =
        plan === 'sessions'
          ? `Subscription created: ${humanPlan(plan)} (${sessions} sessions).`
          : `Subscription created: ${humanPlan(plan)} starting ${startDate}.`
      setSuccessMsg(msg)

      onCreated?.(j)

      setTimeout(() => {
        setPlan(defaultPlan ?? '1m')
        setSessions(Math.min(Math.max(defaultSessions ?? 10, 1), 10))
        setAmount('0')
        setStartDate(defaultStartDate ?? todayLocalDateStr())
        setOpen(false)
        router.refresh()
        setTimeout(() => setSuccessMsg(''), 120)
      }, 900)
    } catch (e: any) {
      setErr(String(e?.message || e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <button
        className="px-2 py-1 rounded border hover:bg-gray-50"
        onClick={() => setOpen(true)}
      >
        {buttonLabel}
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/30" onClick={() => !busy && setOpen(false)} />
          <div className="relative z-10 w-[92vw] max-w-md rounded-xl border bg-white p-4 shadow-xl">
            <div className="flex items-center">
              <h3 className="text-lg font-semibold">New subscription</h3>
              <button
                className="ml-auto text-sm px-2 py-1 rounded hover:bg-gray-100"
                onClick={() => !busy && setOpen(false)}
              >
                Close
              </button>
            </div>

            <div className="mt-2 text-sm text-gray-600">Member: <b>{fullName}</b></div>

            {!!successMsg && (
              <div role="status" aria-live="polite" className="mt-3 rounded-lg border border-green-300 bg-green-50 text-green-800 px-3 py-2 text-sm">
                {successMsg}
              </div>
            )}
            {!!err && (
              <div role="alert" className="mt-3 rounded-lg border border-red-300 bg-red-50 text-red-700 px-3 py-2 text-sm">
                {err}
              </div>
            )}

            <div className="mt-4 grid gap-3">
              <label className="grid gap-1">
                <span className="text-sm">Plan</span>
                <select
                  className="px-3 py-2 border rounded"
                  value={plan}
                  onChange={(e) => setPlan(e.target.value as Plan)}
                  disabled={busy || !!successMsg}
                >
                  <option value="1m">1 month</option>
                  <option value="3m">3 months</option>
                  <option value="6m">6 months</option>
                  <option value="12m">12 months</option>
                  <option value="sessions">Per sessions (45 days)</option>
                </select>
              </label>

              {plan !== 'sessions' && (
                <label className="grid gap-1">
                  <span className="text-sm">Start date (required)</span>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="px-3 py-2 border rounded w-56"
                    disabled={busy || !!successMsg}
                  />
                  <span className="text-xs text-gray-500">
                    Payment date will be set to today automatically.
                  </span>
                </label>
              )}

              {plan === 'sessions' && (
                <label className="grid gap-1">
                  <span className="text-sm">Number of sessions (max 10)</span>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    step={1}
                    value={sessions}
                    onChange={(e) =>
                      setSessions(Math.max(1, Math.min(10, Number(e.target.value || 1))))
                    }
                    className="px-3 py-2 border rounded w-32"
                    disabled={busy || !!successMsg}
                  />
                  <span className="text-xs text-gray-500">Validity: 45 days from start date.</span>
                </label>
              )}

              <label className="grid gap-1">
                <span className="text-sm">Amount</span>
                <input
                  type="number"
                  min={0}
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="px-3 py-2 border rounded w-40"
                  disabled={busy || !!successMsg}
                />
              </label>
            </div>

            <div className="mt-4 flex gap-2">
              <button
                className="px-3 py-2 rounded border hover:bg-gray-50"
                onClick={() => setOpen(false)}
                disabled={busy}
              >
                Cancel
              </button>
              <button
                className={`px-3 py-2 rounded border ${canSubmit ? 'bg-black text-white hover:opacity-90' : 'bg-gray-200 text-gray-500 cursor-not-allowed'}`}
                onClick={submit}
                disabled={!canSubmit || !!successMsg}
              >
                {busy ? 'Saving…' : 'Create subscription'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
