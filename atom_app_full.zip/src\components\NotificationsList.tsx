// src/components/NotificationsList.tsx
'use client'

import { useEffect, useMemo, useState } from 'react'

type Box = 'inbox' | 'sent'
type Item = {
  id: string
  title: string | null
  body: string
  kind: string | null
  created_at: string
  read_at?: string | null
  created_by?: string | null
  user_id?: string | null
  recipient_name?: string
  recipient_email?: string | null
}

const KINDS = ['all', 'info', 'order_update', 'billing', 'promo'] as const
type KindFilter = typeof KINDS[number]

// ✅ Fixe à 5 par page
const PER_PAGE = 5

type Props = {
  isAdmin?: boolean
  /** si true, on force l’onglet "Sent" et on masque l’Inbox et ses actions */
  sentOnly?: boolean
}

export default function NotificationsList({ isAdmin = false, sentOnly = false }: Props) {
  // Si sentOnly, on fige la boîte à 'sent'
  const [box, setBox] = useState<Box>(sentOnly ? 'sent' : 'inbox')
  const [tab, setTab] = useState<'all' | 'unread'>('all') // seulement pour inbox
  const [kind, setKind] = useState<KindFilter>('all')
  const [q, setQ] = useState('')
  const [debQ, setDebQ] = useState('')

  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const [items, setItems] = useState<Item[]>([])
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState<string>('')
  const [selected, setSelected] = useState<Set<string>>(new Set())

  // Si la prop change dynamiquement, réaligne l’onglet
  useEffect(() => {
    if (sentOnly) setBox('sent')
  }, [sentOnly])

  const totalPages = useMemo(() => Math.max(1, Math.ceil(total / PER_PAGE)), [total])

  useEffect(() => {
    const t = setTimeout(() => setDebQ(q.trim()), 300)
    return () => clearTimeout(t)
  }, [q])

  async function load(p = page) {
    setLoading(true)
    setErr('')
    try {
      const params = new URLSearchParams()
      params.set('page', String(p))
      params.set('limit', String(PER_PAGE)) // ✅ toujours 5
      if (kind !== 'all') params.set('kind', kind)
      if (debQ) params.set('q', debQ)

      let url = '/api/notifications/list'
      if (!sentOnly && box === 'inbox' && tab === 'unread') {
        params.set('unread', '1')
      }
      if (sentOnly || box === 'sent') {
        url = '/api/notifications/sent/list'
      }

      const r = await fetch(`${url}?${params.toString()}`, { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setErr(j?.details || j?.error || 'Failed to load')
        setItems([])
        setTotal(0)
        return
      }
      setItems(Array.isArray(j.items) ? j.items : [])
      setTotal(Number(j.total || 0))
      setPage(Number(j.page || p)) // garde la page renvoyée ou celle demandée
      setSelected(new Set())
    } catch (e: any) {
      setErr(String(e?.message || e))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    setPage(1)
    load(1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [box, tab, kind, debQ, sentOnly])

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }
  function toggleAll() {
    if (selected.size === items.length) {
      setSelected(new Set())
    } else {
      setSelected(new Set(items.map((i) => i.id)))
    }
  }

  async function markSelectedRead() {
    if (sentOnly || box !== 'inbox' || selected.size === 0) return
    const ids = Array.from(selected)
    const r = await fetch('/api/notifications/mark-read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids }),
    })
    const j = await r.json().catch(() => ({}))
    if (!r.ok || !j?.ok) {
      alert(j?.details || j?.error || 'Failed to mark as read')
      return
    }
    await load(page)
  }

  async function markAllUnreadInFilterRead() {
    if (sentOnly || box !== 'inbox') return
    const params = new URLSearchParams()
    params.set('page', '1')
    params.set('limit', '1000')
    params.set('unread', '1')
    if (kind !== 'all') params.set('kind', kind)
    if (debQ) params.set('q', debQ)
    const r = await fetch(`/api/notifications/list?${params.toString()}`, { cache: 'no-store' })
    const j = await r.json().catch(() => ({}))
    if (!r.ok || !j?.ok) {
      alert(j?.details || j?.error || 'Failed to load unread')
      return
    }
    const ids: string[] = (j.items || []).map((x: any) => x.id).filter(Boolean)
    if (ids.length === 0) {
      alert('No unread notifications in current filter.')
      return
    }
    const r2 = await fetch('/api/notifications/mark-read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids }),
    })
    const j2 = await r2.json().catch(() => ({}))
    if (!r2.ok || !j2?.ok) {
      alert(j2?.details || j2?.error || 'Failed to mark all as read')
      return
    }
    await load(page)
  }

  function fmtDate(iso: string) {
    try {
      const d = new Date(iso)
      return d.toLocaleString()
    } catch {
      return iso
    }
  }

  return (
    <section className="rounded-xl border bg-white p-4">
      {/* Header & filters */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <h2 className="font-semibold">Notifications</h2>
        {/* Onglets Inbox/Sent masqués si sentOnly */}
        {isAdmin && !sentOnly && (
          <div className="flex gap-1 rounded bg-gray-100 p-1 w-fit">
            <button
              onClick={() => setBox('inbox')}
              className={`px-3 py-1.5 rounded ${box === 'inbox' ? 'bg-white border' : ''}`}
            >
              Inbox
            </button>
            <button
              onClick={() => setBox('sent')}
              className={`px-3 py-1.5 rounded ${box === 'sent' ? 'bg-white border' : ''}`}
            >
              Sent
            </button>
          </div>
        )}

        {/* Onglets All/Unread seulement si Inbox visible */}
        {!sentOnly && box === 'inbox' && (
          <div className="flex gap-1 rounded bg-gray-100 p-1 w-fit">
            <button
              onClick={() => setTab('all')}
              className={`px-3 py-1.5 rounded ${tab === 'all' ? 'bg-white border' : ''}`}
            >
              All
            </button>
            <button
              onClick={() => setTab('unread')}
              className={`px-3 py-1.5 rounded ${tab === 'unread' ? 'bg-white border' : ''}`}
            >
              Unread
            </button>
          </div>
        )}

        <select
          value={kind}
          onChange={(e) => setKind(e.target.value as any)}
          className="px-2 py-2 border rounded"
        >
          {KINDS.map((k) => (
            <option key={k} value={k}>
              {k === 'all' ? 'All kinds' : k}
            </option>
          ))}
        </select>

        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search title/body…"
          className="px-3 py-2 border rounded w-full sm:max-w-xs"
        />

        <div className="sm:ml-auto flex items-center gap-2">
          <button
            onClick={() => load(page)}
            className="px-2 py-1 rounded border bg-white hover:bg-gray-50"
            disabled={loading}
          >
            {loading ? 'Loading…' : 'Refresh'}
          </button>

          {/* Boutons de lecture : seulement si Inbox visible */}
          {!sentOnly && box === 'inbox' && (
            <>
              <button
                onClick={markSelectedRead}
                disabled={selected.size === 0 || loading}
                className="px-2 py-1 rounded border bg-black text-white disabled:opacity-60"
              >
                Mark selected as read
              </button>
              <button
                onClick={markAllUnreadInFilterRead}
                disabled={loading}
                className="px-2 py-1 rounded border bg-white hover:bg-gray-50"
                title="Mark all unread in current filter"
              >
                Mark all unread (filter)
              </button>
            </>
          )}
        </div>
      </div>

      {err && <div className="mt-3 text-sm text-red-600">{err}</div>}

      <div className="mt-3 overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="text-left border-b">
              <th className="p-2">
                {/* Checkbox de sélection uniquement pour Inbox */}
                {!sentOnly && box === 'inbox' && (
                  <input
                    type="checkbox"
                    checked={selected.size === items.length && items.length > 0}
                    onChange={toggleAll}
                  />
                )}
              </th>
              <th className="p-2">Title</th>
              <th className="p-2">Message</th>
              <th className="p-2">Kind</th>
              <th className="p-2">Created</th>
              <th className="p-2">{sentOnly || box === 'sent' ? 'Recipient' : 'Status'}</th>
              <th className="p-2"></th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-3 text-gray-500">
                  No notifications.
                </td>
              </tr>
            ) : (
              items.map((n) => (
                <tr key={n.id} className="border-b align-top">
                  <td className="p-2">
                    {!sentOnly && box === 'inbox' && (
                      <input
                        type="checkbox"
                        checked={selected.has(n.id)}
                        onChange={() => toggle(n.id)}
                      />
                    )}
                  </td>
                  <td className="p-2 font-medium">{n.title || '—'}</td>
                  <td className="p-2 whitespace-pre-wrap">{n.body}</td>
                  <td className="p-2">{n.kind || '—'}</td>
                  <td className="p-2">{fmtDate(n.created_at)}</td>
                  <td className="p-2">
                    {sentOnly || box === 'sent' ? (
                      <div className="text-xs">
                        <div className="font-medium">{n.recipient_name || '—'}</div>
                        <div className="text-gray-500">{n.recipient_email || ''}</div>
                      </div>
                    ) : n.read_at ? (
                      <span className="text-xs px-2 py-0.5 rounded bg-green-100 text-green-700">Read</span>
                    ) : (
                      <span className="text-xs px-2 py-0.5 rounded bg-yellow-100 text-yellow-700">Unread</span>
                    )}
                  </td>
                  <td className="p-2">
                    {!sentOnly && box === 'inbox' && !n.read_at && (
                      <button
                        className="text-xs px-2 py-1 rounded border hover:bg-gray-50"
                        onClick={async () => {
                          const r = await fetch('/api/notifications/mark-read', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ ids: [n.id] }),
                          })
                          const j = await r.json().catch(() => ({}))
                          if (!r.ok || !j?.ok) {
                            alert(j?.details || j?.error || 'Failed')
                            return
                          }
                          await load(page)
                        }}
                      >
                        Mark as read
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="mt-3 flex items-center gap-2">
        <button
          onClick={() => load(Math.max(1, page - 1))}
          disabled={page <= 1 || loading}
          className="px-2 py-1 rounded border bg-white hover:bg-gray-50 disabled:opacity-50"
        >
          Prev
        </button>
        <div className="text-xs text-gray-600">
          Page <strong>{page}</strong> / {totalPages} · Total {total} · {PER_PAGE}/page
        </div>
        <button
          onClick={() => load(Math.min(totalPages, page + 1))}
          disabled={page >= totalPages || loading}
          className="px-2 py-1 rounded border bg-white hover:bg-gray-50 disabled:opacity-50"
        >
          Next
        </button>
      </div>
    </section>
  )
}
