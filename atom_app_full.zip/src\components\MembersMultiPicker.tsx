// src/components/MembersMultiPicker.tsx
'use client'

import { useEffect, useMemo, useRef, useState } from 'react'

type Member = {
  user_id: string
  email: string | null
  first_name: string | null
  last_name: string | null
  phone?: string | null
  // role?: string | null // normalement 'member' côté API
}

export default function MembersMultiPicker({
  onChange,
  initialSelected = [],
  placeholder = 'Search member by name, email, or ID…',
  disabled = false,
}: {
  onChange: (ids: string[]) => void
  initialSelected?: string[]
  placeholder?: string
  disabled?: boolean
}) {
  const [q, setQ] = useState('')
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState<string>('')
  const [items, setItems] = useState<Member[]>([])
  const [selected, setSelected] = useState<Set<string>>(new Set(initialSelected))

  const debTimer = useRef<number | null>(null)

  const query = useMemo(() => q.trim(), [q])

  useEffect(() => {
    // notif parent
    onChange(Array.from(selected))
  }, [selected, onChange])

  useEffect(() => {
    // première charge
    runSearch(query)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    // debounce 300ms
    if (debTimer.current) window.clearTimeout(debTimer.current)
    debTimer.current = window.setTimeout(() => runSearch(query), 300)
    return () => {
      if (debTimer.current) window.clearTimeout(debTimer.current)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query])

  async function runSearch(qs: string) {
    if (disabled) return
    setLoading(true)
    setErr('')
    try {
      const url = new URL('/api/members/search', window.location.origin)
      if (qs) url.searchParams.set('q', qs)
      // L’API renvoie déjà uniquement les 'member'. Si ce n’est pas le cas,
      // ajoute côté serveur `.eq('role','member')`.
      const r = await fetch(url.toString(), { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setErr(j?.error || 'Failed to load members')
        setItems([])
        return
      }
      setItems(Array.isArray(j.items) ? j.items : [])
    } catch (e: any) {
      setErr(String(e?.message || e))
      setItems([])
    } finally {
      setLoading(false)
    }
  }

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function selectAllCurrent() {
    setSelected((prev) => {
      const next = new Set(prev)
      for (const it of items) if (it.user_id) next.add(it.user_id)
      return next
    })
  }

  function clearAll() {
    setSelected(new Set())
  }

  function displayName(m: Member) {
    const n = [m.first_name ?? '', m.last_name ?? ''].join(' ').trim()
    return n || m.email || m.user_id
  }

  return (
    <div className="rounded border bg-gray-50 p-3">
      <div className="flex items-center gap-2">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          className="px-3 py-2 border rounded w-full"
        />
        <button
          type="button"
          onClick={() => runSearch(query)}
          disabled={disabled || loading}
          className="px-3 py-2 rounded border bg-white hover:bg-gray-100"
        >
          {loading ? 'Searching…' : 'Search'}
        </button>
      </div>

      <div className="flex items-center gap-2 mt-2 text-xs text-gray-600">
        <button
          type="button"
          onClick={selectAllCurrent}
          disabled={disabled || items.length === 0}
          className="px-2 py-1 rounded border bg-white hover:bg-gray-100"
        >
          Select all (page)
        </button>
        <button
          type="button"
          onClick={clearAll}
          disabled={disabled || selected.size === 0}
          className="px-2 py-1 rounded border bg-white hover:bg-gray-100"
        >
          Clear
        </button>
        <span className="ml-auto">
          Selected: <strong>{selected.size}</strong>
        </span>
      </div>

      {err && <div className="mt-2 text-sm text-red-600">{err}</div>}

      <div className="mt-2 max-h-64 overflow-auto rounded border bg-white">
        {items.length === 0 && !loading && (
          <div className="p-3 text-sm text-gray-500">No results.</div>
        )}
        {items.map((m) => (
          <label
            key={m.user_id}
            className="flex items-center gap-2 px-3 py-2 border-b last:border-b-0"
          >
            <input
              type="checkbox"
              checked={selected.has(m.user_id)}
              onChange={() => toggle(m.user_id)}
              disabled={disabled}
            />
            <div className="text-sm">
              <div className="font-medium">{displayName(m)}</div>
              <div className="text-xs text-gray-500">{m.email}</div>
            </div>
          </label>
        ))}
      </div>
    </div>
  )
}
