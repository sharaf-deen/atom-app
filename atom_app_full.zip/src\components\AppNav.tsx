// src/components/AppNav.tsx
export const dynamic = 'force-dynamic'
export const revalidate = 0

import Link from 'next/link'
import Image from 'next/image'
import { getSessionUser, type Role } from '@/lib/session'
import SignOutButton from '@/components/SignOutButton'
import NavLoginLink from '@/components/NavLoginLink'
import HideMenuOnRoutes from '@/components/HideMenuOnRoutes'
import TreeMenu, { type MenuItem } from '@/components/TreeMenu'


const STAFF: Role[] = ['reception', 'admin', 'super_admin']

function humanizeRole(role: string) {
  const s = role.replace(/_/g, ' ')
  return s.charAt(0).toUpperCase() + s.slice(1)
}

// Menu par rôle (adapte les routes si besoin)
const MENU: Record<Role, MenuItem[]> = {
  member: [
    { label: 'Store', href: '/store' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'My Profile', href: '/profile' },
    { label: 'Contact Admin', href: '/contact' },
  ],
  assistant_coach: [
    { label: 'Store', href: '/store' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'My Profile', href: '/profile' },
  ],
  coach: [
    { label: 'Store', href: '/store' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'My Profile', href: '/profile' },
  ],
  reception: [
    { label: 'Membership', href: '/kiosk' },
    { label: 'Scan', href: '/scan' },
    { label: 'Members', href: '/members' },
  ],
  admin: [
    { label: 'Dashboard', href: '/admin' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'Membership', href: '/kiosk' },
    { label: 'Scan', href: '/scan' },
    { label: 'Members', href: '/members' },
    { label: 'Coaches', href: '/coaches' },
    { label: 'Store', href: '/store' },
  ],
  super_admin: [
    { label: 'Dashboard', href: '/admin' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'Membership', href: '/kiosk' },
    { label: 'Scan', href: '/scan' },
    { label: 'Members', href: '/members' },
    { label: 'Coaches', href: '/coaches' },
    { label: 'Store', href: '/store' },
  ],
}

export default async function AppNav() {
  const user = await getSessionUser()
  const role = (user?.role as Role) || 'member'
  const items = MENU[role] || []

  const displayName =
    (user as any)?.full_name ||
    [user?.first_name ?? '', user?.last_name ?? ''].join(' ').trim() ||
    user?.email ||
    (user?.role ? humanizeRole(user.role) : 'User')

  return (
    <nav className="sticky top-0 z-40 border-b border-[hsl(var(--border))] bg-white/90 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:bg-[hsl(var(--bg))]/80">
      <div className="mx-auto max-w-6xl px-4 h-12 flex items-center gap-3">
        {/* Brand : swap light/dark sans état client */}
        <Link href="/" className="flex items-center gap-2 group" aria-label="ATOM Jiu-Jitsu">
          {/* Logo clair */}
          <Image
            src="/LogoAtomBlack.svg"
            alt="ATOM Jiu-Jitsu"
            width={112}
            height={28}
            priority
            className="h-7 w-auto transition-opacity group-hover:opacity-90 block dark:hidden"
          />
          {/* Logo sombre */}
          <Image
            src="/LogoAtomWhite.svg"
            alt="ATOM Jiu-Jitsu"
            width={112}
            height={28}
            priority
            className="h-7 w-auto transition-opacity group-hover:opacity-90 hidden dark:block"
          />
          <span className="sr-only">ATOM Jiu-Jitsu</span>
        </Link>

        {/* Bouton “Arbre” (menu déroulant responsive) — masqué sur / et /login */}
        {user && (
          <HideMenuOnRoutes routes={['/', '/login']}>
            <TreeMenu items={items} className="ml-2" buttonLabel="Menu" dimOpacity={0.7} />
          </HideMenuOnRoutes>
        )}

        {/* Côté droit : Theme toggle + Login/Logout */}
        <div className="ml-auto flex items-center gap-3">
          {user ? (
            <>
              <span className="hidden sm:inline text-xs text-[hsl(var(--muted))]">
                {displayName} · <strong>{humanizeRole(role)}</strong>
              </span>
              <SignOutButton />
            </>
          ) : (
            <NavLoginLink />
          )}
        </div>
      </div>
    </nav>
  )
}
