// src/app/members/page.tsx
export const dynamic = 'force-dynamic'
export const revalidate = 0

import MembersSearch from '@/components/MembersSearch'
import { getSessionUser, type Role } from '@/lib/session'

const STAFF: Role[] = ['reception', 'admin', 'super_admin']

export default async function MembersPage() {
  const me = await getSessionUser()
  const isStaff = !!me && STAFF.includes(me.role)

  if (!isStaff) {
    return (
      <main className="p-6">
        <h1 className="text-xl font-semibold">Members</h1>
        <p className="text-sm text-gray-600 mt-2">Forbidden.</p>
      </main>
    )
  }

  return (
    <main className="p-6 space-y-4">
      <div className="flex items-center">
        <h1 className="text-xl font-semibold">Members</h1>
      </div>

      {/* Search & list (staff sees Actions) */}
      <MembersSearch isStaff />
    </main>
  )
}
