// src/app/admin/page.tsx
export const dynamic = 'force-dynamic'
export const revalidate = 0

import Link from 'next/link'
import { createSupabaseRSC } from '@/lib/supabaseServer'
import { getSessionUser } from '@/lib/session'
import AdminRunExpiryButton from '@/components/AdminRunExpiryButton'
import AdminRunNotificationsButton from '@/components/AdminRunNotificationsButton'
import AdminExports from '@/components/AdminExports'
import AdminRevenue from '@/components/AdminRevenue'

type Plan = '1m' | '3m' | '6m' | '12m' | 'sessions'

function todayDateOnly() {
  return new Date().toISOString().slice(0, 10) // YYYY-MM-DD (UTC)
}
function tomorrowDateOnly(d: string) {
  const [y,m,day] = d.split('-').map(Number)
  const dt = new Date(Date.UTC(y, m-1, day))
  dt.setUTCDate(dt.getUTCDate() + 1)
  return dt.toISOString().slice(0,10)
}

export default async function AdminPage() {
  const me = await getSessionUser()
  if (!me || !['admin', 'super_admin'].includes(me.role)) {
    return (
      <main className="p-6">
        <h1 className="text-xl font-semibold">Admin</h1>
        <p className="text-sm text-gray-600 mt-2">Forbidden.</p>
      </main>
    )
  }

  const supa = createSupabaseRSC()
  const today = todayDateOnly()
  const tomorrow = tomorrowDateOnly(today)

  // --- KPI queries (unchanged) ---
  const { count: activeTimeCount } = await supa
    .from('subscriptions')
    .select('id', { count: 'exact', head: true })
    .eq('subscription_type', 'time')
    .eq('status', 'active')
    .gte('end_date', today)

  const { count: activeSessionsCount } = await supa
    .from('subscriptions')
    .select('id', { count: 'exact', head: true })
    .eq('subscription_type', 'sessions')
    .eq('status', 'active')
    .gte('end_date', today)

  const { count: expiredCount } = await supa
    .from('subscriptions')
    .select('id', { count: 'exact', head: true })
    .eq('status', 'expired')

  const { count: attendanceToday } = await supa
    .from('attendance')
    .select('id', { count: 'exact', head: true })
    .eq('valid', true)
    .eq('date', today)

  const { data: activeRows } = await supa
    .from('subscriptions')
    .select('plan, status, end_date')
    .eq('status', 'active')
    .gte('end_date', today)
    .limit(5000) as { data: Array<{ plan: Plan; status: string | null; end_date: string | null }> | null }

  const byPlan: Record<Plan, number> = { '1m': 0, '3m': 0, '6m': 0, '12m': 0, 'sessions': 0 }
  for (const r of activeRows ?? []) {
    if (r.plan && (['1m','3m','6m','12m','sessions'] as Plan[]).includes(r.plan)) {
      byPlan[r.plan] = (byPlan[r.plan] ?? 0) + 1
    }
  }

  // Store KPIs
  const { count: readyCount } = await supa.from('store_orders').select('id', { count: 'exact', head: true }).eq('status','ready')
  const { count: pendingCount } = await supa.from('store_orders').select('id', { count: 'exact', head: true }).eq('status','pending')
  const { count: confirmedCount } = await supa.from('store_orders').select('id', { count: 'exact', head: true }).eq('status','confirmed')
  const { count: deliveredCount } = await supa.from('store_orders').select('id', { count: 'exact', head: true }).eq('status','delivered')
  const { count: canceledCount } = await supa.from('store_orders').select('id', { count: 'exact', head: true }).eq('status','canceled')
  const { count: storeTodayCount } = await supa
    .from('store_orders')
    .select('id', { count: 'exact', head: true })
    .gte('created_at', today)
    .lt('created_at', tomorrow)

  return (
    <main className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <h1 className="text-xl font-semibold">Admin</h1>
      </div>

      {/* KPI Cards (Membership) */}
      <section className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border bg-white p-4">
          <div className="text-sm text-gray-500">Active (subscriptions)</div>
          <div className="text-2xl font-semibold mt-1">{activeTimeCount ?? 0}</div>
          <div className="text-xs text-gray-400 mt-1">end date ≥ today</div>
        </div>

        <div className="rounded-xl border bg-white p-4">
          <div className="text-sm text-gray-500">Active (sessions)</div>
          <div className="text-2xl font-semibold mt-1">{activeSessionsCount ?? 0}</div>
          <div className="text-xs text-gray-400 mt-1">end date ≥ today</div>
        </div>

        <div className="rounded-xl border bg-white p-4">
          <div className="text-sm text-gray-500">Expired (all)</div>
          <div className="text-2xl font-semibold mt-1">{expiredCount ?? 0}</div>
          <div className="text-xs text-gray-400 mt-1">status = expired</div>
        </div>

        <div className="rounded-xl border bg-white p-4">
          <div className="text-sm text-gray-500">Attendance today</div>
          <div className="text-2xl font-semibold mt-1">{attendanceToday ?? 0}</div>
          <div className="text-xs text-gray-400 mt-1">date = {today}</div>
        </div>
      </section>

      {/* Breakdown Active by plan */}
      <section className="rounded-xl border bg-white p-4">
        <h2 className="text-lg font-semibold mb-3">Active subscriptions (by plan)</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {(['1m','3m','6m','12m','sessions'] as Plan[]).map((p) => (
            <div key={p} className="rounded-lg border bg-gray-50 p-3">
              <div className="text-sm text-gray-500">
                {p === 'sessions' ? 'Per sessions' :
                 p === '1m' ? '1 month' :
                 p === '3m' ? '3 months' :
                 p === '6m' ? '6 months' : '12 months'}
              </div>
              <div className="text-xl font-semibold mt-1">{byPlan[p] ?? 0}</div>
            </div>
          ))}
        </div>
        <div className="text-xs text-gray-400 mt-3">
          * Calculated on subscriptions with status = active & end_date ≥ today.
        </div>
      </section>

      {/* Store KPIs */}
      <section className="rounded-xl border bg-white p-4">
        <div className="flex items-center gap-3 mb-3">
          <h2 className="text-lg font-semibold">Store</h2>
          <div className="ml-auto">
            <Link
              href="/store" // <— on envoie vers /store (super admin pourra ajouter des produits directement)
              className="px-3 py-1.5 rounded border bg-black text-white hover:opacity-90"
            >
              Go to Store
            </Link>
          </div>
        </div>

        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-6">
          <div className="rounded-lg border bg-gray-50 p-3">
            <div className="text-sm text-gray-500">Ready</div>
            <div className="text-2xl font-semibold mt-1">{readyCount ?? 0}</div>
          </div>
          <div className="rounded-lg border bg-gray-50 p-3">
            <div className="text-sm text-gray-500">Pending</div>
            <div className="text-2xl font-semibold mt-1">{pendingCount ?? 0}</div>
          </div>
          <div className="rounded-lg border bg-gray-50 p-3">
            <div className="text-sm text-gray-500">Confirmed</div>
            <div className="text-2xl font-semibold mt-1">{confirmedCount ?? 0}</div>
          </div>
          <div className="rounded-lg border bg-gray-50 p-3">
            <div className="text-sm text-gray-500">delivered</div>
            <div className="text-2xl font-semibold mt-1">{deliveredCount ?? 0}</div>
          </div>
          <div className="rounded-lg border bg-gray-50 p-3">
            <div className="text-sm text-gray-500">canceled</div>
            <div className="text-2xl font-semibold mt-1">{canceledCount ?? 0}</div>
          </div>
          <div className="rounded-lg border bg-gray-50 p-3">
            <div className="text-sm text-gray-500">Orders today</div>
            <div className="text-2xl font-semibold mt-1">{storeTodayCount ?? 0}</div>
            <div className="text-xs text-gray-400 mt-1">{today}</div>
          </div>
        </div>
      </section>

      {/* Revenue dashboard */}
      <AdminRevenue />

      {/* Exports (CSV) */}
      <AdminExports />
    </main>
  )
}
