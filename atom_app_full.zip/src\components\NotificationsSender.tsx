// src/components/NotificationsSender.tsx
'use client'

import { useState } from 'react'
import MembersMultiPicker from './MembersMultiPicker'

type Audience =
  | 'all_members'
  | 'all_coaches'
  | 'all_assistant_coaches'
  | 'all_staff'
  | 'custom'

export default function NotificationsSender() {
  const [audience, setAudience] = useState<Audience>('all_members')
  const [customMode, setCustomMode] = useState<'pick' | 'emails'>('pick')
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [emails, setEmails] = useState('')
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [kind, setKind] = useState('info') // optionnel, catégorisation
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState<string>('')

  async function onSend(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true)
    setMsg('')
    try {
      const payload: any = {
        title: title.trim() || undefined,
        body: body.trim(),
        audience,
        kind: kind.trim() || undefined,
      }

      if (audience === 'custom') {
        if (customMode === 'pick') {
          if (selectedIds.length === 0) {
            setMsg('Please select at least one member.')
            setBusy(false)
            return
          }
          payload.user_ids = selectedIds
        } else {
          const arr = emails
            .split(',')
            .map((s) => s.trim().toLowerCase())
            .filter(Boolean)
          if (arr.length === 0) {
            setMsg('Please provide at least one email for custom audience.')
            setBusy(false)
            return
          }
          payload.emails = arr
        }
      }

      const r = await fetch('/api/notifications/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const j = await r.json()
      if (!r.ok || !j?.ok) {
        setMsg(j?.details || j?.error || 'Failed to send')
        return
      }
      setMsg(`Sent to ${j.count} recipient(s).`)
      setBody('')
      setSelectedIds([])
      setEmails('')
    } catch (e: any) {
      setMsg(String(e?.message || e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <section className="rounded-xl border bg-white p-4">
      <h2 className="font-semibold">Send a notification</h2>
      <form onSubmit={onSend} className="mt-3 grid gap-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="grid gap-1">
            <span className="text-sm text-gray-600">Audience</span>
            <select
              value={audience}
              onChange={(e) => setAudience(e.target.value as Audience)}
              className="px-2 py-2 border rounded"
              disabled={busy}
            >
              <option value="all_members">All members</option>
              <option value="all_coaches">All coaches</option>
              <option value="all_assistant_coaches">All assistant coaches</option>
              <option value="all_staff">All coaches + assistants</option>
              <option value="custom">Custom…</option>
            </select>
          </label>

          <label className="grid gap-1">
            <span className="text-sm text-gray-600">Category (optional)</span>
            <select
              value={kind}
              onChange={(e) => setKind(e.target.value)}
              className="px-2 py-2 border rounded"
              disabled={busy}
            >
              <option value="info">Info</option>
              <option value="order_update">Order update</option>
              <option value="billing">Billing</option>
              <option value="promo">Promo</option>
            </select>
          </label>
        </div>

        {audience === 'custom' && (
          <div className="grid gap-2">
            <div className="flex items-center gap-3">
              <label className="text-sm flex items-center gap-1">
                <input
                  type="radio"
                  name="customMode"
                  value="pick"
                  checked={customMode === 'pick'}
                  onChange={() => setCustomMode('pick')}
                />
                <span>Pick members</span>
              </label>
              <label className="text-sm flex items-center gap-1">
                <input
                  type="radio"
                  name="customMode"
                  value="emails"
                  checked={customMode === 'emails'}
                  onChange={() => setCustomMode('emails')}
                />
                <span>Emails</span>
              </label>
            </div>

            {customMode === 'pick' ? (
              <MembersMultiPicker onChange={setSelectedIds} disabled={busy} />
            ) : (
              <label className="grid gap-1">
                <span className="text-sm text-gray-600">Recipient emails (comma-separated)</span>
                <input
                  value={emails}
                  onChange={(e) => setEmails(e.target.value)}
                  className="px-3 py-2 border rounded"
                  placeholder="member1@ex.com, member2@ex.com"
                  disabled={busy}
                />
              </label>
            )}
          </div>
        )}

        <label className="grid gap-1">
          <span className="text-sm text-gray-600">Title (optional)</span>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="px-3 py-2 border rounded"
            placeholder="Update…"
            disabled={busy}
          />
        </label>

        <label className="grid gap-1">
          <span className="text-sm text-gray-600">Message *</span>
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            className="px-3 py-2 border rounded min-h-[120px]"
            placeholder="Your message…"
            disabled={busy}
            required
          />
        </label>

        <div className="flex items-center gap-2">
          <button
            type="submit"
            disabled={
              busy ||
              !body.trim() ||
              (audience === 'custom' && customMode === 'pick' && selectedIds.length === 0) ||
              (audience === 'custom' && customMode === 'emails' && !emails.trim())
            }
            className={`px-3 py-2 rounded border ${
              busy ? 'bg-gray-200 text-gray-500' : 'bg-black text-white hover:opacity-90'
            }`}
          >
            {busy ? 'Sending…' : 'Send'}
          </button>
          {msg && <span className="text-xs text-gray-600">{msg}</span>}
        </div>
      </form>
    </section>
  )
}
