// src/components/NotificationsMemberInbox.tsx
'use client'

import { useEffect, useMemo, useState } from 'react'

type Row = {
  id: string
  title: string | null
  body: string
  kind: string | null
  created_at: string
  read_at: string | null
  created_by: string | null
}

const PER_PAGE = 5

export default function NotificationsMemberInbox() {
  const [items, setItems] = useState<Row[]>([])
  const [loading, setLoading] = useState(false)
  const [msg, setMsg] = useState<string>('')

  // 👇 Ajouts pour la pagination
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const totalPages = useMemo(
    () => Math.max(1, Math.ceil(total / PER_PAGE)),
    [total]
  )

  async function load(p = page) {
    setLoading(true)
    setMsg('')
    try {
      const params = new URLSearchParams()
      params.set('kind', 'member_contact')
      params.set('page', String(p))
      params.set('limit', String(PER_PAGE))

      const r = await fetch(`/api/notifications/list?${params.toString()}`, { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setMsg(j?.details || j?.error || 'Failed to load inbox')
        setItems([])
        setTotal(0)
        return
      }
      setItems(Array.isArray(j.items) ? j.items : [])
      setTotal(Number(j.total || 0))
      setPage(Number(j.page || p))
    } catch (e: any) {
      setMsg(String(e?.message || e))
      setItems([])
      setTotal(0)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load(1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function markAllRead() {
    const unreadIds = items.filter((x) => !x.read_at).map((x) => x.id)
    if (unreadIds.length === 0) return
    setMsg('')
    try {
      const r = await fetch('/api/notifications/mark-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: unreadIds }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setMsg(j?.details || j?.error || 'Failed to mark as read')
        return
      }
      setMsg(`Marked ${unreadIds.length} as read.`)
      await load(page)
    } catch (e: any) {
      setMsg(String(e?.message || e))
    }
  }

  return (
    <section className="rounded-xl border bg-white p-4">
      <div className="flex flex-wrap items-center gap-2">
        <h2 className="font-semibold">Inbox (member messages)</h2>
        <button
          onClick={() => load(page)}
          className="ml-2 text-sm px-2 py-1 rounded border hover:bg-gray-50"
          disabled={loading}
        >
          {loading ? 'Loading…' : 'Refresh'}
        </button>
        <button
          onClick={markAllRead}
          className="text-sm px-2 py-1 rounded border hover:bg-gray-50"
          disabled={loading || items.every((i) => !!i.read_at)}
        >
          Mark all read (this page)
        </button>
        {loading && <span className="text-xs text-gray-500 ml-2">Loading…</span>}
        {msg && <span className="text-xs text-gray-600 ml-2">{msg}</span>}
        <div className="ml-auto text-xs text-gray-600">
          Page <strong>{page}</strong> / {totalPages} · Total {total} · {PER_PAGE}/page
        </div>
      </div>

      <div className="mt-3 grid gap-3">
        {items.length === 0 && (
          <div className="text-sm text-gray-500">No member messages.</div>
        )}

        {items.map((n) => (
          <div
            key={n.id}
            className={`rounded-lg border p-3 ${n.read_at ? 'bg-gray-50' : 'bg-white'}`}
          >
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <span>{new Date(n.created_at).toLocaleString()}</span>
              <span>·</span>
              <span>{n.read_at ? 'read' : 'unread'}</span>
            </div>
            <div className="mt-1 font-medium">
              {n.title || 'Message from member'}
            </div>
            <div className="mt-1 whitespace-pre-wrap text-sm">
              {n.body}
            </div>
            {n.created_by && (
              <div className="mt-2 text-xs text-gray-500">
                {/* reserved for author info if you expose it later */}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Pagination */}
      <div className="mt-4 flex items-center justify-center gap-2">
        <button
          onClick={() => load(Math.max(1, page - 1))}
          disabled={page <= 1 || loading}
          className="px-2 py-1 rounded border bg-white hover:bg-gray-50 disabled:opacity-50"
        >
          Prev
        </button>
        <button
          onClick={() => load(Math.min(totalPages, page + 1))}
          disabled={page >= totalPages || loading}
          className="px-2 py-1 rounded border bg-white hover:bg-gray-50 disabled:opacity-50"
        >
          Next
        </button>
      </div>
    </section>
  )
}
