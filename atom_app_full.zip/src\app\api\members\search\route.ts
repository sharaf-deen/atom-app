// src/app/api/members/search/route.ts
import { NextResponse } from 'next/server'
import type { Role } from '@/lib/session'
import { createSupabaseServerActionClient } from '@/lib/supabaseServer'


export async function GET(req: Request) {
  try {
    const supabase = createSupabaseServerActionClient()

    // Auth
    const { data: authData } = await supabase.auth.getUser()
    const user = authData.user
    if (!user) {
      return NextResponse.json({ ok: false, error: 'NOT_AUTHENTICATED' }, { status: 401 })
    }

    // Vérifier que l’acteur est staff (réception/admin/super_admin)
    const { data: me } = await supabase
      .from('profiles')
      .select('user_id, role')
      .eq('user_id', user.id)
      .maybeSingle<{ user_id: string; role: Role | null }>()

    const role = (me?.role ?? 'member') as Role
    if (!['reception', 'admin', 'super_admin'].includes(role)) {
      return NextResponse.json({ ok: false, error: 'FORBIDDEN' }, { status: 403 })
    }

    // Query string
    const { searchParams } = new URL(req.url)
    const q = (searchParams.get('q') ?? '').trim()

    // Base query: on restreint aux VRAIS membres
    // (Si certains anciens profils ont role NULL, voir note en bas)
    let query = supabase
      .from('profiles')
      .select('user_id, email, first_name, last_name, phone, role, created_at')
      .eq('role', 'member') // ✅ ne retourne que les members
      .order('created_at', { ascending: false })
      .limit(100)

    // Recherche plein-texte simple
    if (q) {
      query = query.or(
        `first_name.ilike.%${q}%,last_name.ilike.%${q}%,email.ilike.%${q}%,member_id.ilike.%${q}%`
      )
    }

    const { data, error } = await query
    if (error) {
      return NextResponse.json({ ok: false, error: 'QUERY_FAILED', details: error.message }, { status: 500 })
    }

    return NextResponse.json({ ok: true, items: data ?? [] })
  } catch (e: any) {
    console.error(e)
    return NextResponse.json({ ok: false, error: 'SERVER_ERROR', details: e?.message }, { status: 500 })
  }
}
