// src/components/StoreProductForm.tsx
'use client'

import { useEffect, useState } from 'react'
import { parsePriceToCents, toPriceString } from '@/lib/money'

type Category = 'kimono' | 'rashguard' | 'short' | 'belt'

type Product = {
  id?: string
  category?: Category
  name: string
  color?: string | null
  size?: string | null
  price_cents: number
  currency?: string | null
  inventory_qty?: number
  is_active?: boolean
}

const CATEGORIES: Category[] = ['kimono', 'rashguard', 'short', 'belt']

export default function StoreProductForm({
  product,
  onSaved,
  onCancel,
}: {
  product?: Product
  onSaved?: () => void
  onCancel?: () => void
}) {
  const [category, setCategory] = useState<Category>(product?.category ?? 'kimono')
  const [name, setName] = useState(product?.name ?? '')
  const [color, setColor] = useState(product?.color ?? '')
  const [size, setSize] = useState(product?.size ?? '')
  // UI price as decimal string (e.g. "450.00")
  const [price, setPrice] = useState<string>(toPriceString(product?.price_cents ?? 0))
  const [currency, setCurrency] = useState(product?.currency ?? 'EGP')
  const [inventory, setInventory] = useState<number>(Number(product?.inventory_qty ?? 0))
  const [active, setActive] = useState<boolean>(product?.is_active ?? true)

  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState<string>('')

  useEffect(() => {
    if (product) {
      setCategory(product.category ?? 'kimono')
      setName(product.name ?? '')
      setColor(product.color ?? '')
      setSize(product.size ?? '')
      setPrice(toPriceString(product.price_cents ?? 0))
      setCurrency(product.currency ?? 'EGP')
      setInventory(Number(product.inventory_qty ?? 0))
      setActive(!!product.is_active || product.is_active === undefined)
    }
  }, [product?.id])

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true)
    setMsg('')
    try {
      const price_cents = parsePriceToCents(price)

      const payload: any = {
        category,
        name: name.trim(),
        color: color.trim() || null,
        size: size.trim() || null,
        price_cents,
        currency: currency || null,
        inventory_qty: Number(inventory ?? 0),
        is_active: !!active,
      }

      let url = '/api/store/products/create'
      let method: 'POST' | 'PATCH' = 'POST'

      if (product?.id) {
        payload.id = product.id
        url = '/api/store/products/update'
        method = 'PATCH'
      }

      const r = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setMsg(j?.details || j?.error || 'Save failed')
        return
      }
      setMsg('Saved')
      onSaved?.()
    } catch (e: any) {
      setMsg(String(e?.message || e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label className="grid gap-1">
          <span className="text-sm">Category *</span>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as Category)}
            className="px-3 py-2 border rounded"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c.replace('_', ' ')}
              </option>
            ))}
          </select>
        </label>

        <label className="grid gap-1">
          <span className="text-sm">Name *</span>
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="px-3 py-2 border rounded"
          />
        </label>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <label className="grid gap-1">
          <span className="text-sm">Color</span>
          <input
            value={color}
            onChange={(e) => setColor(e.target.value)}
            className="px-3 py-2 border rounded"
          />
        </label>
        <label className="grid gap-1">
          <span className="text-sm">Size</span>
          <input
            value={size}
            onChange={(e) => setSize(e.target.value)}
            className="px-3 py-2 border rounded"
          />
        </label>
        <label className="grid gap-1">
          <span className="text-sm">Price *</span>
          <input
            type="number"
            inputMode="decimal"
            step="0.01"
            min="0"
            placeholder="0.00"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            className="px-3 py-2 border rounded"
            required
          />
        </label>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <label className="grid gap-1">
          <span className="text-sm">Currency</span>
          <input
            value={currency ?? 'EGP'}
            onChange={(e) => setCurrency(e.target.value)}
            className="px-3 py-2 border rounded"
            placeholder="EGP"
          />
        </label>

        <label className="grid gap-1">
          <span className="text-sm">Inventory qty</span>
          <input
            type="number"
            min={0}
            value={inventory}
            onChange={(e) => setInventory(Number(e.target.value || 0))}
            className="px-3 py-2 border rounded"
          />
        </label>

        <label className="flex items-center gap-2 mt-7">
          <input
            type="checkbox"
            checked={active}
            onChange={(e) => setActive(e.target.checked)}
          />
          <span className="text-sm">Active</span>
        </label>
      </div>

      <div className="flex items-center gap-2">
        <button
          type="submit"
          disabled={busy || !name.trim()}
          className={`px-3 py-2 rounded border ${busy ? 'bg-gray-200 text-gray-500' : 'bg-black text-white hover:opacity-90'}`}
        >
          {busy ? 'Saving…' : product?.id ? 'Update' : 'Create'}
        </button>
        {onCancel && (
          <button type="button" onClick={onCancel} className="px-3 py-2 rounded border hover:bg-gray-50">
            Cancel
          </button>
        )}
        {msg && <span className="text-xs text-gray-600">{msg}</span>}
      </div>
    </form>
  )
}
