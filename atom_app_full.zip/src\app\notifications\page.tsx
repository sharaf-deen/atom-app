// src/app/notifications/page.tsx
export const dynamic = 'force-dynamic'
export const revalidate = 0

import { getSessionUser } from '@/lib/session'
import NotificationsSender from '@/components/NotificationsSender'
import NotificationsList from '@/components/NotificationsList'
import NotificationsMemberInbox from '@/components/NotificationsMemberInbox'

export default async function NotificationsPage() {
  const me = await getSessionUser()
  if (!me) {
    return (
      <main className="p-6">
        <h1 className="text-xl font-semibold">Notifications</h1>
        <p className="text-sm text-gray-600 mt-2">Please sign in.</p>
      </main>
    )
  }

  const isAdmin = me.role === 'admin'
  const isSuper = me.role === 'super_admin'
  const isMember = me.role === 'member'
  const isCoach = me.role === 'coach'
  const isAssistantCoach = me.role === 'assistant_coach'

  return (
    <main className="p-6 space-y-6">
      <div className="flex items-center gap-2">
        <h1 className="text-xl font-semibold">Notifications</h1>
      </div>

      {/* Création d'annonces (admin + super_admin) */}
      {(isAdmin || isSuper) && <NotificationsSender />}

      {/* 
        - member : affiche sa boîte de réception générale
        - coach et assistant coach : affiche sa boîte de réception générale
        - admin  : seulement “sent” (tu avais demandé d’ignorer l'inbox admin)
        - super_admin : peut aussi voir la section “sent” si tu souhaites
      */}
      {isMember && <NotificationsList />}
      {isCoach && <NotificationsList />}
      {isAssistantCoach && <NotificationsList />}
      {isAdmin && <NotificationsList isAdmin sentOnly />}
      {isSuper && <NotificationsList isAdmin sentOnly />}

      {/* Bloc inbox “member messages” réservé aux super_admin */}
      {isSuper && <NotificationsMemberInbox />}

    </main>
  )
}
