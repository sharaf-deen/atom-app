// src/app/auth/route.ts
import { NextResponse } from 'next/server'
import { createSupabaseRouteClient } from '@/lib/supabaseServer'


/**
 * This endpoint syncs Supabase auth cookies on the server
 * from client-side auth events (SIGNED_IN, TOKEN_REFRESHED, etc.).
 * You should call it from the client on onAuthStateChange(event, session).
 */
export async function POST(req: Request) {
  try {
    const payload = await req.json().catch(() => ({}))
    const event = (payload?.event ?? '') as
      | 'SIGNED_IN'
      | 'TOKEN_REFRESHED'
      | 'INITIAL_SESSION'
      | 'USER_UPDATED'
      | 'VISIBILITY_SYNC'
      | 'SIGNED_OUT'
      | string
    const session = payload?.session ?? null

    const supabase = createSupabaseRouteClient()

    // Events that should set/refresh the server-side session cookies
    const shouldSet =
      event === 'SIGNED_IN' ||
      event === 'TOKEN_REFRESHED' ||
      event === 'INITIAL_SESSION' ||
      event === 'USER_UPDATED' ||
      event === 'VISIBILITY_SYNC'

    if (shouldSet) {
      if (session) {
        const { error } = await supabase.auth.setSession(session)
        if (error) {
          const res = NextResponse.json({ ok: false, error: error.message }, { status: 400 })
          res.headers.set('Cache-Control', 'no-store')
          return res
        }
      } else {
        // No session provided → clear any existing server cookies
        await supabase.auth.signOut()
      }
    }

    if (event === 'SIGNED_OUT') {
      await supabase.auth.signOut()
    }

    const res = NextResponse.json({ ok: true })
    res.headers.set('Cache-Control', 'no-store')
    return res
  } catch (e: any) {
    const res = NextResponse.json(
      { ok: false, error: e?.message || 'Invalid payload' },
      { status: 400 }
    )
    res.headers.set('Cache-Control', 'no-store')
    return res
  }
}
