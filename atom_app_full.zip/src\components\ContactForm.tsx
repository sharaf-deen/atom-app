// src/components/ContactForm.tsx
'use client'

import { useState } from 'react'

export default function ContactForm() {
  const [subject, setSubject] = useState('')
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const [status, setStatus] = useState<string>('')

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true)
    setStatus('')
    try {
      const r = await fetch('/api/contact/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject, message }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j?.ok) {
        setStatus(j?.details || j?.error || 'Failed to send message')
        return
      }
      setStatus('Message sent to Atom admin.')
      setSubject('')
      setMessage('')
    } catch (e: any) {
      setStatus(String(e?.message || e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <section className="rounded-xl border bg-white p-4">
      <form onSubmit={onSubmit} className="grid gap-3">
        <label className="grid gap-1">
          <span className="text-sm text-gray-700">Subject (optional)</span>
          <input
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="px-3 py-2 border rounded"
            placeholder="Question about my subscription, order…"
            disabled={busy}
          />
        </label>

        <label className="grid gap-1">
          <span className="text-sm text-gray-700">Message *</span>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="px-3 py-2 border rounded min-h-[140px]"
            placeholder="Write your message…"
            required
            disabled={busy}
          />
        </label>

        <div className="flex items-center gap-2">
          <button
            type="submit"
            disabled={busy || !message.trim()}
            className={`px-3 py-2 rounded border ${busy ? 'bg-gray-200 text-gray-500' : 'bg-black text-white hover:opacity-90'}`}
          >
            {busy ? 'Sending…' : 'Send'}
          </button>
          {status && <span className="text-xs text-gray-600">{status}</span>}
        </div>
      </form>
    </section>
  )
}
