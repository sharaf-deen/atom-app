// src/components/ProfileSubscriptions.tsx
export const dynamic = 'force-dynamic'
export const revalidate = 0

import { createSupabaseRSC } from '@/lib/supabaseServer'
import { getSessionUser } from '@/lib/session'

type Plan = '1m' | '3m' | '6m' | '12m' | 'sessions'
type SubRow = {
  id: number
  plan: Plan
  subscription_type: 'time' | 'sessions' | null
  status: 'active' | 'paused' | 'canceled' | 'expired' | string | null
  start_date: string | null // YYYY-MM-DD
  end_date: string | null   // YYYY-MM-DD
  amount: number | null
  paid_at: string | null    // ISO
  sessions_total: number | null
  sessions_used: number | null
}

function fmtDate(d?: string | null) {
  if (!d) return '—'
  const date = d.length <= 10 ? new Date(d + 'T00:00:00Z') : new Date(d)
  if (isNaN(date.getTime())) return d
  return date.toLocaleDateString('en-GB', { year: 'numeric', month: 'short', day: '2-digit' })
}

function fmtAmount(n?: number | null) {
  if (n == null) return '—'
  try {
    return new Intl.NumberFormat('en', { style: 'currency', currency: 'EUR' }).format(n)
  } catch {
    return Number(n).toFixed(2)
  }
}

function humanPlan(p: Plan) {
  const map: Record<Plan, string> = {
    '1m': '1 month',
    '3m': '3 months',
    '6m': '6 months',
    '12m': '12 months',
    'sessions': 'Per sessions',
  }
  return map[p] ?? p
}

function isActive(row: SubRow): { active: boolean; remaining?: number | null } {
  const todayStr = new Date().toISOString().slice(0, 10)

  if (row.plan === 'sessions') {
    const total = row.sessions_total ?? 0
    const used = row.sessions_used ?? 0
    const remaining = Math.max(total - used, 0)
    const active = (row.status === 'active') && remaining > 0
    return { active, remaining }
  }

  const active =
    row.status === 'active' &&
    (!!row.end_date && row.end_date >= todayStr)

  return { active }
}

export default async function ProfileSubscriptions() {
  const user = await getSessionUser()
  if (!user) {
    return (
      <section className="mt-6">
        <h2 className="text-lg font-semibold mb-2">Subscriptions</h2>
        <div className="text-sm text-gray-600">Please sign in to view your subscriptions.</div>
      </section>
    )
  }

  const supa = createSupabaseRSC()
  const { data, error } = await supa
    .from('subscriptions')
    .select('id, plan, subscription_type, status, start_date, end_date, amount, paid_at, sessions_total, sessions_used')
    .eq('member_id', user.id)
    .order('start_date', { ascending: false }) as { data: SubRow[] | null, error: any }

  if (error) {
    return (
      <section className="mt-6">
        <h2 className="text-lg font-semibold mb-2">Subscriptions</h2>
        <div className="text-sm text-red-600">Failed to load subscriptions.</div>
      </section>
    )
  }

  const rows = data ?? []

  return (
    <section className="mt-6">
      <h2 className="text-lg font-semibold mb-3">Subscriptions</h2>

      {rows.length === 0 ? (
        <div className="text-sm text-gray-600">You have no subscriptions yet.</div>
      ) : (
        <div className="grid gap-3">
          {rows.map((row) => {
            const { active, remaining } = isActive(row)
            const isSessions = row.plan === 'sessions'

            return (
              <div key={row.id} className="rounded-xl border p-4 bg-white">
                {/* 🔢 Big counter for sessions (prominent, above the card body) */}
                {isSessions && (
                  <div className="mb-3 flex items-end justify-between">
                    <div className="text-sm text-gray-600">Sessions remaining</div>
                    <div
                      className={`text-3xl font-extrabold tabular-nums ${
                        active ? 'text-green-600' : 'text-red-600'
                      }`}
                      title={
                        typeof remaining === 'number'
                          ? `${remaining} sessions remaining`
                          : 'No data'
                      }
                    >
                      {typeof remaining === 'number' ? remaining : '—'}
                    </div>
                  </div>
                )}

                {/* Badges row */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm px-2 py-0.5 rounded-full border bg-gray-50">
                    {humanPlan(row.plan)}
                  </span>

                  {isSessions && (
                    <span className="text-xs px-2 py-0.5 rounded-full border bg-gray-50">
                      {typeof remaining === 'number' ? `${remaining} left` : 'Sessions'}
                    </span>
                  )}

                  <span
                    className={`ml-auto text-xs px-2 py-0.5 rounded-full border ${
                      active
                        ? 'border-green-500 text-green-700 bg-green-50'
                        : 'border-red-500 text-red-700 bg-red-50'
                    }`}
                    title={`Status: ${row.status ?? 'unknown'}`}
                  >
                    {active ? 'Active' : 'Expired / Inactive'}
                  </span>
                </div>

                {/* Details grid */}
                <div className="mt-3 grid sm:grid-cols-2 md:grid-cols-3 gap-2 text-sm">
                  <div className="space-y-0.5">
                    <div className="text-gray-500">Start</div>
                    <div className="font-medium">{fmtDate(row.start_date)}</div>
                  </div>
                  <div className="space-y-0.5">
                    <div className="text-gray-500">End</div>
                    <div className="font-medium">{fmtDate(row.end_date)}</div>
                  </div>
                  <div className="space-y-0.5">
                    <div className="text-gray-500">Amount</div>
                    <div className="font-medium">{fmtAmount(row.amount)}</div>
                  </div>
                  <div className="space-y-0.5">
                    <div className="text-gray-500">Paid at</div>
                    <div className="font-medium">{fmtDate(row.paid_at)}</div>
                  </div>

                  {isSessions && (
                    <>
                      <div className="space-y-0.5">
                        <div className="text-gray-500">Total sessions</div>
                        <div className="font-medium">{row.sessions_total ?? '—'}</div>
                      </div>
                      <div className="space-y-0.5">
                        <div className="text-gray-500">Used</div>
                        <div className="font-medium">{row.sessions_used ?? 0}</div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </section>
  )
}
