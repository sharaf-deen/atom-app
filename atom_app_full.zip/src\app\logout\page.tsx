'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';

export default function LogoutPage() {
  const router = useRouter();

  useEffect(() => {
    const run = async () => {
      const supabase = createBrowserClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
      );
      await supabase.auth.signOut(); // AuthListener enverra SIGNED_OUT → /auth nettoiera les cookies serveur
      router.replace('/login');
    };
    run();
  }, [router]);

  return (
    <main className="max-w-sm mx-auto p-6">
      <h1 className="text-xl font-bold">Signing out…</h1>
    </main>
  );
}
