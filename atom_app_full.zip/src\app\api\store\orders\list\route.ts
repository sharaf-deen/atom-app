// src/app/api/store/orders/list/route.ts
export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const revalidate = 0

import { NextResponse } from 'next/server'
import { createSupabaseServerActionClient } from '@/lib/supabaseServer'


function noStore(res: NextResponse) {
  res.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate')
  return res
}

type ProductRow = {
  id: string
  category: string
  name: string
  color?: string | null
  size?: string | null
  price_cents: number
  currency?: string | null
}

type OrderItemRow = {
  id: string
  product_id: string
  qty: number
  unit_price_cents: number
  final_price_cents: number
  currency?: string | null
  name?: string | null
  product?: ProductRow | null
}

type OrderRow = {
  id: string
  user_id: string
  member_id?: string | null
  status: string
  total_cents: number
  discount_pct: number | null
  preferred_payment: string | null
  note: string | null
  created_at: string
  items?: OrderItemRow[]
}

type Enriched = OrderRow & {
  customer_email?: string | null
  customer_name?: string | null
}

export async function GET(req: Request) {
  try {
    const supa = createSupabaseServerActionClient()

    // Auth
    const { data: auth, error: authErr } = await supa.auth.getUser()
    if (authErr) {
      return noStore(NextResponse.json({ ok: false, error: 'AUTH_ERROR', details: authErr.message }, { status: 401 }))
    }
    const user = auth.user
    if (!user) return noStore(NextResponse.json({ ok: false, error: 'NOT_AUTHENTICATED' }, { status: 401 }))

    // Rôle
    const { data: me } = await supa
      .from('profiles')
      .select('role')
      .eq('user_id', user.id)
      .maybeSingle<{ role: string | null }>()
    const isSuperAdmin = (me?.role ?? '') === 'super_admin'

    // Params
    const { searchParams } = new URL(req.url)
    const page = Math.max(1, Number(searchParams.get('page') || 1))
    const limit = Math.min(100, Math.max(1, Number(searchParams.get('limit') || 20)))
    const view = (searchParams.get('view') || '').toLowerCase()
    const from = (page - 1) * limit
    const to = from + limit - 1

    // ---- SELECT avec désambiguïsation via les noms de FKs ----
    // Remplace les noms si les tiens diffèrent.
    const selectWithItems =
      'id,user_id,member_id,status,total_cents,discount_pct,preferred_payment,note,created_at,' +
      // items via FK: store_order_items.order_id -> store_orders.id
      'items:store_order_items!store_order_items_order_id_fkey(' +
      '  id,product_id,qty,unit_price_cents,final_price_cents,currency,name,' +
      // produit via FK: store_order_items.product_id -> store_products.id
      '  product:store_products!store_order_items_product_id_fkey(id,category,name,color,size,price_cents,currency)' +
      ')'

    // Total (pagination)
    let countQuery = supa.from('store_orders').select('id', { count: 'exact', head: true })
    if (!(isSuperAdmin && view === 'all')) countQuery = countQuery.eq('user_id', user.id)
    const { count, error: countErr } = await countQuery
    if (countErr) {
      return noStore(NextResponse.json({ ok: false, error: 'COUNT_FAILED', details: countErr.message }, { status: 500 }))
    }

    // Page de données
    let pageQuery = supa
      .from('store_orders')
      .select(selectWithItems as any, { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(from, to)

    if (!(isSuperAdmin && view === 'all')) pageQuery = pageQuery.eq('user_id', user.id)

    const { data, error } = await pageQuery
    if (error) {
      return noStore(NextResponse.json({ ok: false, error: 'QUERY_FAILED', details: error.message }, { status: 500 }))
    }

    const rows = (Array.isArray(data) ? data : []) as unknown as OrderRow[]

    // Enrichissement client (optionnel)
    const uidSet = new Set(rows.map(o => o.user_id).filter(Boolean))
    let map: Record<string, { email: string | null; first_name: string | null; last_name: string | null }> = {}
    if (uidSet.size > 0) {
      const { data: profs } = await supa
        .from('profiles')
        .select('user_id,email,first_name,last_name')
        .in('user_id', Array.from(uidSet))
        .limit(uidSet.size)
      if (profs) {
        map = Object.fromEntries(
          profs.map(p => [p.user_id, { email: p.email, first_name: p.first_name, last_name: p.last_name }])
        )
      }
    }

    const items: Enriched[] = rows.map(o => {
      const p = map[o.user_id]
      const full = ((p?.first_name ?? '') + ' ' + (p?.last_name ?? '')).trim() || null
      return {
        ...o,
        customer_email: p?.email ?? null,
        customer_name: full,
        items: o.items ?? [],
      }
    })

    return noStore(NextResponse.json({
      ok: true,
      page,
      pageSize: limit,
      total: count ?? items.length,
      items,
    }))
  } catch (e: any) {
    return noStore(NextResponse.json({ ok: false, error: 'SERVER_ERROR', details: e?.message || String(e) }, { status: 500 }))
  }
}
