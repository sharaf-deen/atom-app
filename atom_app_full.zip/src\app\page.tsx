// src/app/page.tsx
export const dynamic = 'force-dynamic'
export const revalidate = 0

import Link from 'next/link'
import { getSessionUser, type Role } from '@/lib/session'
import { createSupabaseRSC } from '@/lib/supabaseServer'

type SessionUser = {
  id: string
  email: string | null
  role: Role
  first_name?: string | null
  last_name?: string | null
}

function humanizeRole(role: string) {
  const s = role.replace(/_/g, ' ')
  return s.charAt(0).toUpperCase() + s.slice(1)
}

async function getDisplayName(u: SessionUser): Promise<string> {
  const sessionName = [u.first_name ?? '', u.last_name ?? ''].join(' ').trim()
  if (sessionName) return sessionName

  try {
    const supabase = createSupabaseRSC()
    const { data, error } = await supabase
      .from('profiles')
      .select('first_name,last_name,email')
      .eq('user_id', u.id)
      .maybeSingle()

    if (!error && data) {
      const fromDb = [data.first_name ?? '', data.last_name ?? ''].join(' ').trim()
      if (fromDb) return fromDb
      if (data.email) return data.email
    }
  } catch {}

  return u.email ?? humanizeRole(u.role)
}

type MenuItem = { label: string; href: string; desc?: string }
type MenuByRole = Record<Role, MenuItem[]>

const MENU: MenuByRole = {
  member: [
    { label: 'Store', href: '/store' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'My Profile', href: '/profile' },
    { label: 'Contact Admin', href: '/contact' },
  ],
  assistant_coach: [
    { label: 'Store', href: '/store' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'My Profile', href: '/profile' },
  ],
  coach: [
    { label: 'Store', href: '/store' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'My Profile', href: '/profile' },
  ],
  reception: [
    { label: 'Membership', href: '/kiosk' },
    { label: 'Scan', href: '/scan' },
    { label: 'Members', href: '/members' },
  ],
  admin: [
    { label: 'Dashboard', href: '/admin' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'Membership', href: '/kiosk' },
    { label: 'Scan', href: '/scan' },
    { label: 'Members', href: '/members' },
    { label: 'Coaches', href: '/coaches' },
    { label: 'Store', href: '/store' },
  ],
  super_admin: [
    { label: 'Dashboard', href: '/admin' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'Membership', href: '/kiosk' },
    { label: 'Scan', href: '/scan' },
    { label: 'Members', href: '/members' },
    { label: 'Coaches', href: '/coaches' },
    { label: 'Store', href: '/store' },
  ],
}

function MenuGrid({ items }: { items: MenuItem[] }) {
  if (!items?.length) {
    return <p className="text-center text-gray-500">No items available for your role.</p>
  }
  return (
    <div className="mt-6 grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((it) => (
        <Link
          key={it.href}
          href={it.href}
          className="group block rounded-2xl border border-[hsl(var(--border))] bg-white p-5 shadow-soft hover:shadow-md hover:shadow-black/10 transition ease-soft focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-[hsl(var(--bg))]"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold tracking-tight">{it.label}</h3>
            <span aria-hidden className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-[hsl(var(--border))] transition group-hover:translate-x-0.5">→</span>
          </div>
          {it.desc && <p className="mt-1 text-sm text-[hsl(var(--muted))]">{it.desc}</p>}
        </Link>
      ))}
    </div>
  )
}

export default async function HomePage() {
  const user = (await getSessionUser()) as SessionUser | null
  const displayName = user ? await getDisplayName(user) : null
  const role: Role | null = user?.role ?? null
  const items = role ? MENU[role] : []

  return (
    <main className="min-h-[calc(100vh-3rem)] bg-white text-black">
      <section className="mx-auto max-w-6xl px-4 py-8">
        {user ? (
          <>
            <h1 className="text-2xl font-semibold tracking-tight">Welcome, {displayName}</h1>
            <MenuGrid items={items} />
          </>
        ) : (
          <p className="mt-6 text-gray-500">Please sign in to see your menu.</p>
        )}
      </section>

      <footer className="mx-auto max-w-6xl px-4 pb-10 pt-2 text-xs text-gray-500">
        © {new Date().getFullYear()} ATOM Jiu-Jitsu
      </footer>
    </main>
  )
}
