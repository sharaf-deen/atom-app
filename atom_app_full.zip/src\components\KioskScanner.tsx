// src/components/KioskScanner.tsx
'use client'

import { useCallback, useState } from 'react'
import { Scanner } from '@yudiel/react-qr-scanner'

type ScanResponse = {
  ok: boolean
  valid?: boolean
  message?: string
  member_id?: string
  subscription_id?: string | null
}

type Detected = { rawValue: string }

function parseMemberText(text: string): string | null {
  const t = (text || '').trim()
  if (!t) return null
  if (t.startsWith('atom:')) return t.slice(5)
  if (t.startsWith('ATOM:')) return t.slice(5)
  if (/^[0-9a-f-]{36}$/i.test(t)) return t
  return null
}

function errToString(err: unknown) {
  if (typeof err === 'string') return err
  if (err && typeof err === 'object' && 'message' in err) {
    const m = (err as any).message
    if (typeof m === 'string') return m
  }
  try { return JSON.stringify(err) } catch {}
  return 'Camera error'
}

export default function KioskScanner() {
  const [paused, setPaused] = useState(false)
  const [msg, setMsg] = useState<string>('Ready')

  const handleScan = useCallback(async (codes: Detected[]) => {
    if (!codes || codes.length === 0 || paused) return
    const raw = codes[0]?.rawValue ?? ''
    if (!raw) return

    // pause tout de suite pour éviter les doublons
    setPaused(true)
    setMsg('Checking…')

    try {
      // On laisse l'API valider le format; parseMemberText sert juste à filtrer les cas absurdes
      const maybeId = parseMemberText(raw)
      const payload = { code: maybeId ? `atom:${maybeId}` : raw }

      const r = await fetch('/api/kiosk/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const j: ScanResponse = await r.json().catch(() => ({ ok: false, message: 'Invalid response' }))
      if (!r.ok || !j.ok) {
        setMsg(j.message || 'Scan failed')
      } else {
        setMsg(j.valid ? 'OK: SUBSCRIPTION VALID' : 'SUBSCRIPTION EXPIRED / INVALID')
      }
    } catch (e) {
      setMsg(errToString(e))
    }
  }, [paused])

  return (
    <div className="rounded-xl border bg-white p-4">
      <h3 className="text-lg font-semibold">Scan member QR</h3>
      <p className="text-sm text-gray-500 mt-1">
        Hold the QR code in front of the camera. We’ll record attendance if valid.
      </p>

      <div className="mt-3 rounded-lg overflow-hidden">
        <Scanner
          constraints={{ facingMode: 'environment' }}
          onScan={handleScan}
          onError={(err) => setMsg(errToString(err))}
          components={{ finder: false }}
          paused={paused}
          styles={{
            container: { width: '100%', aspectRatio: '4 / 3' },
            video: { width: '100%', height: 'auto', objectFit: 'cover' },
          }}
        />
      </div>

      <div className="mt-2 flex items-center gap-2">
        <button
          className={`px-3 py-1.5 rounded border ${paused ? 'bg-white hover:bg-gray-50' : 'bg-gray-200 text-gray-500 cursor-not-allowed'}`}
          onClick={() => setPaused(false)}
          disabled={!paused}
        >
          Rescan
        </button>
        <span className="text-sm text-gray-700">{msg}</span>
      </div>
    </div>
  )
}
